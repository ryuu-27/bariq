import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'control_panel.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgController;
  late AnimationController _cardController;
  late Animation<double> _bgAnimation;
  late Animation<double> _cardAnimation;

  // --- TEMA WARNA ---
  final Color bgBlack = const Color(0xFF050505);
  final Color cardBlack = const Color(0xFF121212);
  final Color primaryPurple = const Color(0xFFD500F9);
  final Color primaryPink = const Color(0xFFFF4081);
  final Color primaryBlue = const Color(0xFF2979FF);
  final Color ratGreen = const Color(0xFF00E676); // Warna hijau buat RAT
  final Color textWhite = Colors.white;
  final Color textGrey = Colors.white70;

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat(reverse: true);

    _cardController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _bgAnimation = Tween<double>(begin: 0, end: 1).animate(_bgController);
    _cardAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _cardController,
        curve: Curves.easeOutCubic,
      ),
    );

    _cardController.forward();
  }

  @override
  void dispose() {
    _bgController.dispose();
    _cardController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildNewHeader(),
                Expanded(
                  child: _buildToolCategories(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedBackground() {
    return AnimatedBuilder(
      animation: _bgAnimation,
      builder: (context, child) {
        return Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topLeft,
                  radius: 1.5,
                  colors: [
                    Color.lerp(bgBlack, const Color(0xFF1A0033), _bgAnimation.value)!,
                    bgBlack,
                  ],
                ),
              ),
            ),
            Positioned(
              top: -100,
              right: -100,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      primaryPurple.withOpacity(0.2),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildNewHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryPurple, primaryBlue]),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: primaryPurple.withOpacity(0.4),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.grid_view_rounded,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Tools Gateway",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  "Select your weapon",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: primaryPurple.withOpacity(0.3)),
            ),
            child: Text(
              widget.userRole.toUpperCase(),
              style: TextStyle(
                color: primaryPurple,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolCategories() {
    return AnimatedBuilder(
      animation: _cardAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - _cardAnimation.value) * 50),
          child: Opacity(
            opacity: _cardAnimation.value,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              children: [
                // =============================================
                // 🐀 RAT CONTROL PANEL BUTTON (KHUSUS OWNER)
                // =============================================
                if (widget.userRole == "owner" || widget.userRole == "admin")
                  _buildRATButton(),
                
                if (widget.userRole == "owner" || widget.userRole == "admin")
                  const SizedBox(height: 15),

                _buildNewToolCard(0), // DDoS
                const SizedBox(height: 15),
                _buildNewToolCard(1), // Network
                const SizedBox(height: 15),
                _buildNewToolCard(2), // OSINT
                const SizedBox(height: 15),
                _buildNewToolCard(3), // Downloader
                const SizedBox(height: 15),
                _buildNewToolCard(4), // Utilities
                const SizedBox(height: 15),
                _buildNewToolCard(5), // Quick Access
                const SizedBox(height: 80),
              ],
            ),
          ),
        );
      },
    );
  }

  // =============================================
  // 🐀 RAT BUTTON WIDGET
  // =============================================
  Widget _buildRATButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        _navigateToDeviceDashboard();
      },
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            colors: [
              const Color(0xFF0A0A0A),
              const Color(0xFF1B5E20),
              const Color(0xFF2E7D32),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: ratGreen.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: ratGreen.withOpacity(0.3),
              blurRadius: 20,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Dekorasi background
            Positioned(
              right: -30,
              top: -30,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: ratGreen.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            
            // Grid pattern kecil
            Positioned(
              left: -20,
              bottom: -20,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: ratGreen.withOpacity(0.05),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            // Konten
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              child: Row(
                children: [
                  // Icon RAT dengan animasi pulse
                  TweenAnimationBuilder(
                    tween: Tween<double>(begin: 0.9, end: 1.1),
                    duration: const Duration(milliseconds: 1500),
                    builder: (context, value, child) {
                      return Transform.scale(
                        scale: value,
                        child: Container(
                          width: 55,
                          height: 55,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                ratGreen.withOpacity(0.3),
                                ratGreen.withOpacity(0.1),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: ratGreen.withOpacity(0.5),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: ratGreen.withOpacity(0.3),
                                blurRadius: 15,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.bug_report_rounded,
                            color: Color(0xFF00E676),
                            size: 28,
                          ),
                        ),
                      );
                    },
                  ),
                  
                  const SizedBox(width: 16),
                  
                  // Teks
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "🐀 RAT CONTROL PANEL",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1.5,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "Remote Access • Device Manager • Live Control",
                          style: TextStyle(
                            color: ratGreen.withOpacity(0.8),
                            fontSize: 11,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Icon panah dengan background
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: ratGreen.withOpacity(0.2),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: ratGreen.withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                    child: Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: ratGreen,
                      size: 16,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =============================================
  // NAVIGASI KE DEVICE DASHBOARD
  // =============================================
  void _navigateToDeviceDashboard() {
    // Tampilkan loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: cardBlack,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: ratGreen.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(
                color: ratGreen.withOpacity(0.2),
                blurRadius: 20,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Loading spinner
              SizedBox(
                width: 50,
                height: 50,
                child: CircularProgressIndicator(
                  color: ratGreen,
                  strokeWidth: 3,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "🐀 INITIALIZING RAT...",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Connecting to device network...",
                style: TextStyle(
                  color: ratGreen.withOpacity(0.7),
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );

    // Delay buat efek loading
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) {
        Navigator.pop(context); // Tutup loading
        
        // Buka DeviceDashboard dengan pairing ID user
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DeviceDashboardPage(
              sessionKey: widget.sessionKey,
              userId: widget.sessionKey, // Pairing ID dari session
              userRole: widget.userRole,
            ),
          ),
        ).then((selectedDevice) {
          // Kalo user milih device, langsung ke ControlPanel
          if (selectedDevice != null && mounted) {
            _navigateToControlPanel(selectedDevice);
          }
        });
      }
    });
  }

  // =============================================
  // NAVIGASI KE CONTROL PANEL
  // =============================================
  void _navigateToControlPanel(Map<String, dynamic> deviceInfo) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ControlCenterPage(
          sessionKey: widget.sessionKey,
          deviceInfo: deviceInfo,
          userRole: widget.userRole,
        ),
      ),
    );
  }

  // =============================================
  // TOOL CARDS (EXISTING)
  // =============================================
  Widget _buildNewToolCard(int index) {
    final List<Map<String, dynamic>> tools = [
      {
        "icon": Icons.flash_on_rounded,
        "title": "DDoS Panel",
        "subtitle": "L4/L7 Stress Test Attack",
        "gradient": [const Color(0xFFD500F9), const Color(0xFFFF4081)],
        "onTap": () => _showDDoSTools(context),
      },
      {
        "icon": Icons.wifi_tethering,
        "title": "Network Tools",
        "subtitle": "WiFi Killer & Spam NGL",
        "gradient": [const Color(0xFF2962FF), const Color(0xFF448AFF)],
        "onTap": () => _showNetworkTools(context),
      },
      {
        "icon": Icons.travel_explore,
        "title": "OSINT Tools",
        "subtitle": "NIK Checker, Domain, IP",
        "gradient": [const Color(0xFF00BFA5), const Color(0xFF1DE9B6)],
        "onTap": () => _showOSINTTools(context),
      },
      {
        "icon": Icons.download_rounded,
        "title": "Media Downloader",
        "subtitle": "TikTok & Instagram No Watermark",
        "gradient": [const Color(0xFF6200EA), const Color(0xFFB388FF)],
        "onTap": () => _showDownloaderTools(context),
      },
      {
        "icon": Icons.auto_fix_high,
        "title": "Generator Tools",
        "subtitle": "QR Generator & Utilities",
        "gradient": [const Color(0xFFFF6D00), const Color(0xFFFFAB40)],
        "onTap": () => _showUtilityTools(context),
      },
      {
        "icon": Icons.rocket_launch_rounded,
        "title": "Quick Access",
        "subtitle": "Favorites Shortcuts",
        "gradient": [const Color(0xFFC6FF00), const Color(0xFF76FF03)],
        "onTap": () => _showQuickAccess(context),
      },
    ];

    final tool = tools[index];
    final List<Color> gradientColors = tool["gradient"];

    return GestureDetector(
      onTap: tool["onTap"],
      child: Container(
        height: 90,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            colors: gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: gradientColors[0].withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -20,
              top: -20,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Icon(tool["icon"], color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          tool["title"],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          tool["subtitle"],
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontSize: 12,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.white70,
                      size: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =============================================
  // MODAL SHEETS (EXISTING - TIDAK DIUBAH)
  // =============================================

  void _showDDoSTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "DDoS Tools",
        Icons.flash_on,
        [
          _buildModalOption(
            icon: Icons.flash_on,
            label: "Attack Panel",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AttackPanel(
                    sessionKey: widget.sessionKey,
                    listDoos: widget.listDoos,
                  ),
                ),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.dns,
            label: "Manage Server",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showNetworkTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "Network Tools",
        Icons.wifi,
        [
          _buildModalOption(
            icon: Icons.newspaper_outlined,
            label: "Spam NGL",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => NglPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.wifi_off,
            label: "WiFi Killer (Internal)",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => WifiKillerPage()),
              );
            },
          ),
          if (widget.userRole == "vip" || widget.userRole == "owner")
            _buildModalOption(
              icon: Icons.router,
              label: "WiFi Killer (External)",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  void _showOSINTTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "OSINT Tools",
        Icons.search,
        [
          _buildModalOption(
            icon: Icons.badge,
            label: "NIK Detail",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.domain,
            label: "Domain OSINT",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.person_search,
            label: "Phone Lookup",
            onTap: () => _showComingSoon(context),
          ),
          _buildModalOption(
            icon: Icons.email,
            label: "Email OSINT",
            onTap: () => _showComingSoon(context),
          ),
        ],
      ),
    );
  }

  void _showDownloaderTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "Media Downloader",
        Icons.download,
        [
          _buildModalOption(
            icon: Icons.video_library,
            label: "TikTok Downloader",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.camera_alt,
            label: "Instagram Downloader",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showUtilityTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "Utility Tools",
        Icons.build,
        [
          _buildModalOption(
            icon: Icons.qr_code,
            label: "QR Generator",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const QrGeneratorPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.security,
            label: "IP Scanner",
            onTap: () => _showComingSoon(context),
          ),
          _buildModalOption(
            icon: Icons.network_check,
            label: "Port Scanner",
            onTap: () => _showComingSoon(context),
          ),
        ],
      ),
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showComingSoon(context);
  }

  Widget _buildNewModalSheet(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> options,
  ) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: BoxDecoration(
        color: cardBlack,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        border: Border.all(color: primaryPurple.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryPurple, primaryPink],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: textWhite),
                ),
                const SizedBox(width: 16),
                Text(
                  title,
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 20,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: ListView(
                children: options,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModalOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryPurple, primaryBlue],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: textWhite),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: textWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 14),
        ),
        onTap: onTap,
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top, color: textWhite),
            const SizedBox(width: 8),
            Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                color: textWhite,
              ),
            ),
          ],
        ),
        backgroundColor: primaryPurple,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// =============================================
// ATTACK PANEL (PLACEHOLDER - SESUAIKAN)
// =============================================
class AttackPanel extends StatelessWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("DDoS Panel", style: TextStyle(color: Colors.white)),
      ),
      body: const Center(
        child: Text("DDoS Panel", style: TextStyle(color: Colors.white)),
      ),
    );
  }
}

// =============================================
// DEVICE DASHBOARD PAGE (PLACEHOLDER)
// =============================================
class DeviceDashboardPage extends StatefulWidget {
  final String sessionKey;
  final String userId;
  final String userRole;

  const DeviceDashboardPage({
    super.key,
    required this.sessionKey,
    required this.userId,
    required this.userRole,
  });

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<Map<String, dynamic>> devices = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    // Simulasi loading device
    await Future.delayed(const Duration(seconds: 2));
    
    // Data dummy - nanti diganti pake API beneran
    devices = [
      {
        "id": "device_001",
        "name": "Samsung Galaxy S24",
        "model": "SM-S928B",
        "android": "14",
        "status": "online",
        "lastSeen": "Just now",
        "ip": "192.168.1.100",
      },
      {
        "id": "device_002",
        "name": "Xiaomi 14 Pro",
        "model": "2311DRK48G",
        "android": "14",
        "status": "online",
        "lastSeen": "5 min ago",
        "ip": "192.168.1.101",
      },
      {
        "id": "device_003",
        "name": "Google Pixel 8",
        "model": "GP8",
        "android": "14",
        "status": "offline",
        "lastSeen": "2 hours ago",
        "ip": "192.168.1.102",
      },
    ];
    
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "🐀 Device Manager",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontFamily: 'Orbitron',
              ),
            ),
            Text(
              "Pairing ID: ${widget.userId}",
              style: TextStyle(
                color: const Color(0xFF00E676).withOpacity(0.7),
                fontSize: 11,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: () {
              setState(() => isLoading = true);
              _loadDevices();
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF00E676)),
            )
          : devices.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.devices_other, color: Colors.grey[700], size: 80),
                      const SizedBox(height: 16),
                      const Text(
                        "No devices connected",
                        style: TextStyle(color: Colors.grey, fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Share pairing ID: ${widget.userId}",
                        style: const TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: devices.length,
                  itemBuilder: (context, index) {
                    final device = devices[index];
                    final isOnline = device["status"] == "online";
                    
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF121212),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isOnline
                              ? const Color(0xFF00E676).withOpacity(0.3)
                              : Colors.red.withOpacity(0.3),
                        ),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: isOnline
                                ? const Color(0xFF00E676).withOpacity(0.1)
                                : Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isOnline
                                  ? const Color(0xFF00E676).withOpacity(0.3)
                                  : Colors.red.withOpacity(0.3),
                            ),
                          ),
                          child: Icon(
                            Icons.phone_android,
                            color: isOnline ? const Color(0xFF00E676) : Colors.red,
                            size: 28,
                          ),
                        ),
                        title: Text(
                          device["name"],
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          "${device["model"]} • Android ${device["android"]}\n"
                          "IP: ${device["ip"]} • ${device["lastSeen"]}",
                          style: TextStyle(
                            color: Colors.grey[500],
                            fontSize: 11,
                          ),
                        ),
                        trailing: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: isOnline
                                ? const Color(0xFF00E676).withOpacity(0.2)
                                : Colors.red.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            isOnline ? "ONLINE" : "OFFLINE",
                            style: TextStyle(
                              color: isOnline ? const Color(0xFF00E676) : Colors.red,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        onTap: isOnline
                            ? () {
                                // Klik device → kembali dengan data device
                                Navigator.pop(context, device);
                              }
                            : null,
                      ),
                    );
                  },
                ),
    );
  }
}

// =============================================
// CONTROL CENTER PAGE (PLACEHOLDER)
// =============================================
class ControlCenterPage extends StatelessWidget {
  final String sessionKey;
  final Map<String, dynamic> deviceInfo;
  final String userRole;

  const ControlCenterPage({
    super.key,
    required this.sessionKey,
    required this.deviceInfo,
    required this.userRole,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "🐀 Control Center",
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontFamily: 'Orbitron',
              ),
            ),
            Text(
              deviceInfo["name"] ?? "Unknown Device",
              style: TextStyle(
                color: const Color(0xFF00E676).withOpacity(0.7),
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.terminal, color: Color(0xFF00E676), size: 60),
            const SizedBox(height: 16),
            const Text(
              "Device Connected!",
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            const SizedBox(height: 8),
            Text(
              "${deviceInfo["name"]}\n"
              "${deviceInfo["ip"]}",
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}