import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  static const Color _bg       = Color(0xFF080500);
  static const Color _card     = Color(0xFF1A1400);
  static const Color _cardBrd  = Color(0xFF2A1F00);
  static const Color _blue     = Color(0xFFFFD700);
  static const Color _blueDark = Color(0xFFB8860B);

  @override
  void initState() {
    super.initState();
    _videoCtrl = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(1.0);
        _videoCtrl.play();
      });

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [

              // ── Header logo + versi ──────────────────────────
              SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _cardBrd),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset('assets/images/logo.jpg',
                              width: 42, height: 42, fit: BoxFit.cover),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 7),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _cardBrd),
                        ),
                        child: const Text('V3.0',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 12,
                              fontFamily: 'Rajdhani',
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.5,
                            )),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // ── Judul EXPOLION paling atas (seperti Ovalium Ghost) ──
              const Text(
                'E X P O L I O N',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _blue,
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Rajdhani',
                  letterSpacing: 6,
                ),
              ),

              const SizedBox(height: 16),

              // ── Judul besar DI ATAS banner ───────────────────
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  'PREMIUM SECURITY',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 3,
                    height: 1.1,
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // ── Subtitle pill ────────────────────────────────
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: Colors.white.withOpacity(0.15)),
                ),
                child: const Text(
                  'ENTERPRISE GRADE PROTECTION',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 2.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              const SizedBox(height: 22),

              // ── Banner video ─────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  height: 240,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: _blue.withOpacity(0.2),
                        blurRadius: 22,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        _videoCtrl.value.isInitialized
                            ? FittedBox(
                                fit: BoxFit.cover,
                                child: SizedBox(
                                  width: _videoCtrl.value.size.width,
                                  height: _videoCtrl.value.size.height,
                                  child: VideoPlayer(_videoCtrl),
                                ),
                              )
                            : Container(color: _blueDark),
                        // Overlay gradient bawah
                        DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                Colors.black.withOpacity(0.6),
                              ],
                              stops: const [0.5, 1.0],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // ── Tombol ACCESS LOGIN (solid) ──────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pushNamed(context, '/login'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Ink(
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [_blueDark, _blue],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: _blue.withOpacity(0.4),
                            blurRadius: 14,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          'ACCESS LOGIN',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 3,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // ── Tombol BUY ACCESS (outline) ──────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: OutlinedButton(
                    onPressed: () => _openUrl('https://t.me/marketryuu'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _blue,
                      side: BorderSide(color: _blue.withOpacity(0.6), width: 1.5),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: const Text(
                      'BUY ACCESS',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 3,
                        color: _blue,
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // ── Connect With Us ──────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 18),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: _cardBrd),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'CONNECT WITH US',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 11,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 2.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildSocialChip(
                            icon: FontAwesomeIcons.telegram,
                            label: 'Telegram',
                            url: 'https://t.me/RyuuuTzyy',
                            color: const Color(0xFFFFD700),
                          ),
                          const SizedBox(width: 12),
                          _buildSocialChip(
                            icon: FontAwesomeIcons.tiktok,
                            label: 'TikTok',
                            url: 'https://www.tiktok.com/@zz4zahraae_',
                            color: Colors.white,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // ── Stat cards 3 kolom ───────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    _buildStatCard(Icons.lock_outline, '256-BIT', 'ENCRYPTION'),
                    const SizedBox(width: 10),
                    _buildStatCard(Icons.trending_up, '99.9%', 'UPTIME'),
                    const SizedBox(width: 10),
                    _buildStatCard(Icons.headset_mic_outlined, '24/7', 'SUPPORT'),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              // ── Footer ───────────────────────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 20),
                decoration: BoxDecoration(
                  border: Border(
                      top: BorderSide(color: Colors.white.withOpacity(0.06))),
                ),
                child: const Text(
                  '© 2026 Expolion - All Rights Reserved',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white24,
                    fontSize: 11,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSocialChip({
    required IconData icon,
    required String label,
    required String url,
    required Color color,
  }) {
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            FaIcon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Text(label,
                style: TextStyle(
                  color: color,
                  fontSize: 13,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w700,
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(IconData icon, String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _cardBrd),
        ),
        child: Column(
          children: [
            Icon(icon, color: _blue, size: 24),
            const SizedBox(height: 8),
            Text(value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                )),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 9,
                  fontFamily: 'Rajdhani',
                  letterSpacing: 1.5,
                )),
          ],
        ),
      ),
    );
  }
}
