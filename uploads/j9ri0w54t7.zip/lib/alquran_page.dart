import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

// ─────────────────────────────────────────────
//  COLOR CONSTANTS (same palette)
// ─────────────────────────────────────────────
const Color kBgPrimary    = Color(0xFF050D1A);
const Color kBgSecondary  = Color(0xFF0A1628);
const Color kBgCard       = Color(0xFF0D1E35);
const Color kBgCard2      = Color(0xFF0F2040);
const Color kBluePrimary  = Color(0xFF1A6CF0);
const Color kBlueBright   = Color(0xFF2D8AFF);
const Color kBlueAccent   = Color(0xFF00B4FF);
const Color kBlueDark     = Color(0xFF0A2D6E);
const Color kGold         = Color(0xFFF0A030);
const Color kGoldLight    = Color(0xFFFFD060);
const Color kTextPrimary  = Color(0xFFE8F0FF);
const Color kTextSecondary= Color(0xFF8AADDD);
const Color kTextMuted    = Color(0xFF4A6A9A);
const Color kBorder       = Color(0x4D1E50B4);
const Color kBorderBright = Color(0x802D8AFF);
const Color kTeal         = Color(0xFF00C8B4);

// ─────────────────────────────────────────────
//  MODELS
// ─────────────────────────────────────────────
class SurahInfo {
  final int number;
  final String nameEn;
  final String nameArab;
  final String place;
  final int ayatCount;
  final String meaning;

  const SurahInfo({
    required this.number,
    required this.nameEn,
    required this.nameArab,
    required this.place,
    required this.ayatCount,
    required this.meaning,
  });
}

class AyatData {
  final int number;
  final String arabic;
  final String latin;
  final String translation;

  const AyatData({
    required this.number,
    required this.arabic,
    required this.latin,
    required this.translation,
  });
}

// ─────────────────────────────────────────────
//  STATIC SURAH LIST (114 surah names)
// ─────────────────────────────────────────────
const List<SurahInfo> kSurahList = [
  SurahInfo(number: 1,   nameEn: 'AL-FATIHAH',   nameArab: 'الفاتحة',   place: 'Mekah',   ayatCount: 7,   meaning: 'Pembukaan'),
  SurahInfo(number: 2,   nameEn: 'AL-BAQARAH',   nameArab: 'البقرة',    place: 'Madinah', ayatCount: 286, meaning: 'Sapi Betina'),
  SurahInfo(number: 3,   nameEn: 'ALI IMRAN',    nameArab: 'آل عمران',  place: 'Madinah', ayatCount: 200, meaning: 'Keluarga Imran'),
  SurahInfo(number: 4,   nameEn: 'AN-NISA',      nameArab: 'النساء',    place: 'Madinah', ayatCount: 176, meaning: 'Perempuan'),
  SurahInfo(number: 5,   nameEn: 'AL-MAIDAH',    nameArab: 'المائدة',   place: 'Madinah', ayatCount: 120, meaning: 'Hidangan'),
  SurahInfo(number: 6,   nameEn: 'AL-ANAM',      nameArab: 'الأنعام',   place: 'Mekah',   ayatCount: 165, meaning: 'Binatang Ternak'),
  SurahInfo(number: 7,   nameEn: 'AL-ARAF',      nameArab: 'الأعراف',   place: 'Mekah',   ayatCount: 206, meaning: 'Tempat Tertinggi'),
  SurahInfo(number: 8,   nameEn: 'AL-ANFAL',     nameArab: 'الأنفال',   place: 'Madinah', ayatCount: 75,  meaning: 'Rampasan Perang'),
  SurahInfo(number: 9,   nameEn: 'AT-TAUBAH',    nameArab: 'التوبة',    place: 'Madinah', ayatCount: 129, meaning: 'Pengampunan'),
  SurahInfo(number: 10,  nameEn: 'YUNUS',        nameArab: 'يونس',      place: 'Mekah',   ayatCount: 109, meaning: 'Nabi Yunus'),
  SurahInfo(number: 11,  nameEn: 'HUD',          nameArab: 'هود',       place: 'Mekah',   ayatCount: 123, meaning: 'Nabi Hud'),
  SurahInfo(number: 12,  nameEn: 'YUSUF',        nameArab: 'يوسف',      place: 'Mekah',   ayatCount: 111, meaning: 'Nabi Yusuf'),
  SurahInfo(number: 13,  nameEn: 'AR-RAD',       nameArab: 'الرعد',     place: 'Madinah', ayatCount: 43,  meaning: 'Guruh'),
  SurahInfo(number: 14,  nameEn: 'IBRAHIM',      nameArab: 'ابراهيم',   place: 'Mekah',   ayatCount: 52,  meaning: 'Nabi Ibrahim'),
  SurahInfo(number: 15,  nameEn: 'AL-HIJR',      nameArab: 'الحجر',     place: 'Mekah',   ayatCount: 99,  meaning: 'Batu'),
  SurahInfo(number: 16,  nameEn: 'AN-NAHL',      nameArab: 'النحل',     place: 'Mekah',   ayatCount: 128, meaning: 'Lebah'),
  SurahInfo(number: 17,  nameEn: 'AL-ISRA',      nameArab: 'الإسراء',   place: 'Mekah',   ayatCount: 111, meaning: 'Perjalanan Malam'),
  SurahInfo(number: 18,  nameEn: 'AL-KAHF',      nameArab: 'الكهف',     place: 'Mekah',   ayatCount: 110, meaning: 'Gua'),
  SurahInfo(number: 19,  nameEn: 'MARYAM',       nameArab: 'مريم',      place: 'Mekah',   ayatCount: 98,  meaning: 'Maryam'),
  SurahInfo(number: 20,  nameEn: 'THAHA',        nameArab: 'طه',        place: 'Mekah',   ayatCount: 135, meaning: 'Tha Ha'),
  SurahInfo(number: 21,  nameEn: 'AL-ANBIYA',    nameArab: 'الأنبياء',  place: 'Mekah',   ayatCount: 112, meaning: 'Para Nabi'),
  SurahInfo(number: 22,  nameEn: 'AL-HAJJ',      nameArab: 'الحج',      place: 'Madinah', ayatCount: 78,  meaning: 'Haji'),
  SurahInfo(number: 23,  nameEn: 'AL-MUMINUN',   nameArab: 'المؤمنون',  place: 'Mekah',   ayatCount: 118, meaning: 'Orang Beriman'),
  SurahInfo(number: 24,  nameEn: 'AN-NUR',       nameArab: 'النور',     place: 'Madinah', ayatCount: 64,  meaning: 'Cahaya'),
  SurahInfo(number: 25,  nameEn: 'AL-FURQAN',    nameArab: 'الفرقان',   place: 'Mekah',   ayatCount: 77,  meaning: 'Pembeda'),
  SurahInfo(number: 26,  nameEn: 'ASY-SYUARA',   nameArab: 'الشعراء',   place: 'Mekah',   ayatCount: 227, meaning: 'Para Penyair'),
  SurahInfo(number: 27,  nameEn: 'AN-NAML',      nameArab: 'النمل',     place: 'Mekah',   ayatCount: 93,  meaning: 'Semut'),
  SurahInfo(number: 28,  nameEn: 'AL-QASAS',     nameArab: 'القصص',     place: 'Mekah',   ayatCount: 88,  meaning: 'Cerita'),
  SurahInfo(number: 29,  nameEn: 'AL-ANKABUT',   nameArab: 'العنكبوت',  place: 'Mekah',   ayatCount: 69,  meaning: 'Laba-laba'),
  SurahInfo(number: 30,  nameEn: 'AR-RUM',       nameArab: 'الروم',     place: 'Mekah',   ayatCount: 60,  meaning: 'Bangsa Romawi'),
  SurahInfo(number: 31,  nameEn: 'LUQMAN',       nameArab: 'لقمان',     place: 'Mekah',   ayatCount: 34,  meaning: 'Luqman'),
  SurahInfo(number: 32,  nameEn: 'AS-SAJDAH',    nameArab: 'السجدة',    place: 'Mekah',   ayatCount: 30,  meaning: 'Sujud'),
  SurahInfo(number: 33,  nameEn: 'AL-AHZAB',     nameArab: 'الأحزاب',   place: 'Madinah', ayatCount: 73,  meaning: 'Golongan'),
  SurahInfo(number: 34,  nameEn: 'SABA',         nameArab: 'سبأ',       place: 'Mekah',   ayatCount: 54,  meaning: 'Kaum Saba'),
  SurahInfo(number: 35,  nameEn: 'FATIR',        nameArab: 'فاطر',      place: 'Mekah',   ayatCount: 45,  meaning: 'Pencipta'),
  SurahInfo(number: 36,  nameEn: 'YASIN',        nameArab: 'يس',        place: 'Mekah',   ayatCount: 83,  meaning: 'Ya Sin'),
  SurahInfo(number: 37,  nameEn: 'AS-SAFFAT',    nameArab: 'الصافات',   place: 'Mekah',   ayatCount: 182, meaning: 'Barisan'),
  SurahInfo(number: 38,  nameEn: 'SHAD',         nameArab: 'ص',         place: 'Mekah',   ayatCount: 88,  meaning: 'Shad'),
  SurahInfo(number: 39,  nameEn: 'AZ-ZUMAR',     nameArab: 'الزمر',     place: 'Mekah',   ayatCount: 75,  meaning: 'Rombongan'),
  SurahInfo(number: 40,  nameEn: 'AL-MUMIN',     nameArab: 'غافر',      place: 'Mekah',   ayatCount: 85,  meaning: 'Orang Beriman'),
  SurahInfo(number: 41,  nameEn: 'FUSSILAT',     nameArab: 'فصلت',      place: 'Mekah',   ayatCount: 54,  meaning: 'Dijelaskan'),
  SurahInfo(number: 42,  nameEn: 'ASY-SYURA',    nameArab: 'الشورى',    place: 'Mekah',   ayatCount: 53,  meaning: 'Musyawarah'),
  SurahInfo(number: 43,  nameEn: 'AZ-ZUKHRUF',   nameArab: 'الزخرف',    place: 'Mekah',   ayatCount: 89,  meaning: 'Perhiasan'),
  SurahInfo(number: 44,  nameEn: 'AD-DUKHAN',    nameArab: 'الدخان',    place: 'Mekah',   ayatCount: 59,  meaning: 'Kabut'),
  SurahInfo(number: 45,  nameEn: 'AL-JATSIYAH',  nameArab: 'الجاثية',   place: 'Mekah',   ayatCount: 37,  meaning: 'Berlutut'),
  SurahInfo(number: 46,  nameEn: 'AL-AHQAF',     nameArab: 'الأحقاف',   place: 'Mekah',   ayatCount: 35,  meaning: 'Bukit Pasir'),
  SurahInfo(number: 47,  nameEn: 'MUHAMMAD',     nameArab: 'محمد',      place: 'Madinah', ayatCount: 38,  meaning: 'Muhammad'),
  SurahInfo(number: 48,  nameEn: 'AL-FATH',      nameArab: 'الفتح',     place: 'Madinah', ayatCount: 29,  meaning: 'Kemenangan'),
  SurahInfo(number: 49,  nameEn: 'AL-HUJURAT',   nameArab: 'الحجرات',   place: 'Madinah', ayatCount: 18,  meaning: 'Kamar'),
  SurahInfo(number: 50,  nameEn: 'QAF',          nameArab: 'ق',         place: 'Mekah',   ayatCount: 45,  meaning: 'Qaf'),
  SurahInfo(number: 51,  nameEn: 'AZ-ZARIYAT',   nameArab: 'الذاريات',  place: 'Mekah',   ayatCount: 60,  meaning: 'Angin'),
  SurahInfo(number: 52,  nameEn: 'AT-TUR',       nameArab: 'الطور',     place: 'Mekah',   ayatCount: 49,  meaning: 'Bukit Sinai'),
  SurahInfo(number: 53,  nameEn: 'AN-NAJM',      nameArab: 'النجم',     place: 'Mekah',   ayatCount: 62,  meaning: 'Bintang'),
  SurahInfo(number: 54,  nameEn: 'AL-QAMAR',     nameArab: 'القمر',     place: 'Mekah',   ayatCount: 55,  meaning: 'Bulan'),
  SurahInfo(number: 55,  nameEn: 'AR-RAHMAN',    nameArab: 'الرحمن',    place: 'Madinah', ayatCount: 78,  meaning: 'Yang Pengasih'),
  SurahInfo(number: 56,  nameEn: 'AL-WAQIAH',    nameArab: 'الواقعة',   place: 'Mekah',   ayatCount: 96,  meaning: 'Hari Kiamat'),
  SurahInfo(number: 57,  nameEn: 'AL-HADID',     nameArab: 'الحديد',    place: 'Madinah', ayatCount: 29,  meaning: 'Besi'),
  SurahInfo(number: 58,  nameEn: 'AL-MUJADILAH', nameArab: 'المجادلة',  place: 'Madinah', ayatCount: 22,  meaning: 'Perdebatan'),
  SurahInfo(number: 59,  nameEn: 'AL-HASYR',     nameArab: 'الحشر',     place: 'Madinah', ayatCount: 24,  meaning: 'Pengusiran'),
  SurahInfo(number: 60,  nameEn: 'AL-MUMTAHANAH',nameArab: 'الممتحنة',  place: 'Madinah', ayatCount: 13,  meaning: 'Perempuan Diuji'),
  SurahInfo(number: 61,  nameEn: 'AS-SAFF',      nameArab: 'الصف',      place: 'Madinah', ayatCount: 14,  meaning: 'Barisan'),
  SurahInfo(number: 62,  nameEn: 'AL-JUMUAH',    nameArab: 'الجمعة',    place: 'Madinah', ayatCount: 11,  meaning: 'Jumat'),
  SurahInfo(number: 63,  nameEn: 'AL-MUNAFIQUN', nameArab: 'المنافقون', place: 'Madinah', ayatCount: 11,  meaning: 'Orang Munafik'),
  SurahInfo(number: 64,  nameEn: 'AT-TAGABUN',   nameArab: 'التغابن',   place: 'Madinah', ayatCount: 18,  meaning: 'Hari Dinampakkan'),
  SurahInfo(number: 65,  nameEn: 'AT-TALAQ',     nameArab: 'الطلاق',    place: 'Madinah', ayatCount: 12,  meaning: 'Talak'),
  SurahInfo(number: 66,  nameEn: 'AT-TAHRIM',    nameArab: 'التحريم',   place: 'Madinah', ayatCount: 12,  meaning: 'Pengharaman'),
  SurahInfo(number: 67,  nameEn: 'AL-MULK',      nameArab: 'الملك',     place: 'Mekah',   ayatCount: 30,  meaning: 'Kerajaan'),
  SurahInfo(number: 68,  nameEn: 'AL-QALAM',     nameArab: 'القلم',     place: 'Mekah',   ayatCount: 52,  meaning: 'Pena'),
  SurahInfo(number: 69,  nameEn: 'AL-HAQQAH',    nameArab: 'الحاقة',    place: 'Mekah',   ayatCount: 52,  meaning: 'Kenyataan'),
  SurahInfo(number: 70,  nameEn: 'AL-MAARIJ',    nameArab: 'المعارج',   place: 'Mekah',   ayatCount: 44,  meaning: 'Tempat Naik'),
  SurahInfo(number: 71,  nameEn: 'NUH',          nameArab: 'نوح',       place: 'Mekah',   ayatCount: 28,  meaning: 'Nabi Nuh'),
  SurahInfo(number: 72,  nameEn: 'AL-JINN',      nameArab: 'الجن',      place: 'Mekah',   ayatCount: 28,  meaning: 'Jin'),
  SurahInfo(number: 73,  nameEn: 'AL-MUZZAMMIL', nameArab: 'المزمل',    place: 'Mekah',   ayatCount: 20,  meaning: 'Orang Berselimut'),
  SurahInfo(number: 74,  nameEn: 'AL-MUDDASSIR', nameArab: 'المدثر',    place: 'Mekah',   ayatCount: 56,  meaning: 'Orang Berkemul'),
  SurahInfo(number: 75,  nameEn: 'AL-QIYAMAH',   nameArab: 'القيامة',   place: 'Mekah',   ayatCount: 40,  meaning: 'Kiamat'),
  SurahInfo(number: 76,  nameEn: 'AL-INSAN',     nameArab: 'الإنسان',   place: 'Madinah', ayatCount: 31,  meaning: 'Manusia'),
  SurahInfo(number: 77,  nameEn: 'AL-MURSALAT',  nameArab: 'المرسلات',  place: 'Mekah',   ayatCount: 50,  meaning: 'Malaikat Diutus'),
  SurahInfo(number: 78,  nameEn: 'AN-NABA',      nameArab: 'النبأ',     place: 'Mekah',   ayatCount: 40,  meaning: 'Berita'),
  SurahInfo(number: 79,  nameEn: 'AN-NAZIAT',    nameArab: 'النازعات',  place: 'Mekah',   ayatCount: 46,  meaning: 'Malaikat Pencabut'),
  SurahInfo(number: 80,  nameEn: 'ABASA',        nameArab: 'عبس',       place: 'Mekah',   ayatCount: 42,  meaning: 'Bermuka Masam'),
  SurahInfo(number: 81,  nameEn: 'AT-TAKWIR',    nameArab: 'التكوير',   place: 'Mekah',   ayatCount: 29,  meaning: 'Menggulung'),
  SurahInfo(number: 82,  nameEn: 'AL-INFITAR',   nameArab: 'الإنفطار',  place: 'Mekah',   ayatCount: 19,  meaning: 'Terbelah'),
  SurahInfo(number: 83,  nameEn: 'AL-MUTAFFIFIN',nameArab: 'المطففين',  place: 'Mekah',   ayatCount: 36,  meaning: 'Curang'),
  SurahInfo(number: 84,  nameEn: 'AL-INSYIQAQ',  nameArab: 'الإنشقاق',  place: 'Mekah',   ayatCount: 25,  meaning: 'Terbelah'),
  SurahInfo(number: 85,  nameEn: 'AL-BURUJ',     nameArab: 'البروج',    place: 'Mekah',   ayatCount: 22,  meaning: 'Gugusan Bintang'),
  SurahInfo(number: 86,  nameEn: 'AT-TARIQ',     nameArab: 'الطارق',    place: 'Mekah',   ayatCount: 17,  meaning: 'Bintang Malam'),
  SurahInfo(number: 87,  nameEn: 'AL-ALA',       nameArab: 'الأعلى',    place: 'Mekah',   ayatCount: 19,  meaning: 'Yang Paling Tinggi'),
  SurahInfo(number: 88,  nameEn: 'AL-GASYIYAH',  nameArab: 'الغاشية',   place: 'Mekah',   ayatCount: 26,  meaning: 'Peristiwa'),
  SurahInfo(number: 89,  nameEn: 'AL-FAJR',      nameArab: 'الفجر',     place: 'Mekah',   ayatCount: 30,  meaning: 'Fajar'),
  SurahInfo(number: 90,  nameEn: 'AL-BALAD',     nameArab: 'البلد',     place: 'Mekah',   ayatCount: 20,  meaning: 'Negeri'),
  SurahInfo(number: 91,  nameEn: 'ASY-SYAMS',    nameArab: 'الشمس',     place: 'Mekah',   ayatCount: 15,  meaning: 'Matahari'),
  SurahInfo(number: 92,  nameEn: 'AL-LAIL',      nameArab: 'الليل',     place: 'Mekah',   ayatCount: 21,  meaning: 'Malam'),
  SurahInfo(number: 93,  nameEn: 'AD-DUHA',      nameArab: 'الضحى',     place: 'Mekah',   ayatCount: 11,  meaning: 'Waktu Duha'),
  SurahInfo(number: 94,  nameEn: 'AL-INSYIRAH',  nameArab: 'الشرح',     place: 'Mekah',   ayatCount: 8,   meaning: 'Kelapangan'),
  SurahInfo(number: 95,  nameEn: 'AT-TIN',       nameArab: 'التين',     place: 'Mekah',   ayatCount: 8,   meaning: 'Buah Tin'),
  SurahInfo(number: 96,  nameEn: 'AL-ALAQ',      nameArab: 'العلق',     place: 'Mekah',   ayatCount: 19,  meaning: 'Segumpal Darah'),
  SurahInfo(number: 97,  nameEn: 'AL-QADR',      nameArab: 'القدر',     place: 'Mekah',   ayatCount: 5,   meaning: 'Kemuliaan'),
  SurahInfo(number: 98,  nameEn: 'AL-BAYYINAH',  nameArab: 'البينة',    place: 'Madinah', ayatCount: 8,   meaning: 'Bukti'),
  SurahInfo(number: 99,  nameEn: 'AZ-ZALZALAH',  nameArab: 'الزلزلة',   place: 'Madinah', ayatCount: 8,   meaning: 'Guncangan'),
  SurahInfo(number: 100, nameEn: 'AL-ADIYAT',    nameArab: 'العاديات',  place: 'Mekah',   ayatCount: 11,  meaning: 'Kuda Perang'),
  SurahInfo(number: 101, nameEn: "AL-QARI'AH",   nameArab: 'القارعة',   place: 'Mekah',   ayatCount: 11,  meaning: 'Hari Kiamat'),
  SurahInfo(number: 102, nameEn: 'AT-TAKASUR',   nameArab: 'التكاثر',   place: 'Mekah',   ayatCount: 8,   meaning: 'Bermegahan'),
  SurahInfo(number: 103, nameEn: 'AL-ASR',       nameArab: 'العصر',     place: 'Mekah',   ayatCount: 3,   meaning: 'Masa'),
  SurahInfo(number: 104, nameEn: 'AL-HUMAZAH',   nameArab: 'الهمزة',    place: 'Mekah',   ayatCount: 9,   meaning: 'Pengumpat'),
  SurahInfo(number: 105, nameEn: 'AL-FIL',       nameArab: 'الفيل',     place: 'Mekah',   ayatCount: 5,   meaning: 'Gajah'),
  SurahInfo(number: 106, nameEn: 'QURAISY',      nameArab: 'قريش',      place: 'Mekah',   ayatCount: 4,   meaning: 'Suku Quraisy'),
  SurahInfo(number: 107, nameEn: "AL-MA'UN",     nameArab: 'الماعون',   place: 'Mekah',   ayatCount: 7,   meaning: 'Bantuan'),
  SurahInfo(number: 108, nameEn: 'AL-KAUSAR',    nameArab: 'الكوثر',    place: 'Mekah',   ayatCount: 3,   meaning: 'Nikmat'),
  SurahInfo(number: 109, nameEn: 'AL-KAFIRUN',   nameArab: 'الكافرون',  place: 'Mekah',   ayatCount: 6,   meaning: 'Orang Kafir'),
  SurahInfo(number: 110, nameEn: 'AN-NASR',      nameArab: 'النصر',     place: 'Madinah', ayatCount: 3,   meaning: 'Pertolongan'),
  SurahInfo(number: 111, nameEn: 'AL-MASAD',     nameArab: 'المسد',     place: 'Mekah',   ayatCount: 5,   meaning: 'Gejolak Api'),
  SurahInfo(number: 112, nameEn: 'AL-IKHLAS',    nameArab: 'الإخلاص',   place: 'Mekah',   ayatCount: 4,   meaning: 'Ikhlas'),
  SurahInfo(number: 113, nameEn: 'AL-FALAQ',     nameArab: 'الفلق',     place: 'Mekah',   ayatCount: 5,   meaning: 'Fajar'),
  SurahInfo(number: 114, nameEn: 'AN-NAS',       nameArab: 'الناس',     place: 'Mekah',   ayatCount: 6,   meaning: 'Manusia'),
];

// ─────────────────────────────────────────────
//  AL-QURAN SCREEN
// ─────────────────────────────────────────────
class AlQuranPage extends StatefulWidget {
  const AlQuranPage({super.key});

  @override
  State<AlQuranPage> createState() => _AlQuranPageState();
}

class _AlQuranPageState extends State<AlQuranPage> {
  int _selectedSurah = 1;
  bool _loading = false;
  bool _showDropdown = false;
  List<AyatData> _ayatList = [];
  String _error = '';

  SurahInfo get _currentSurah =>
      kSurahList.firstWhere((s) => s.number == _selectedSurah);

  @override
  void initState() {
    super.initState();
    _loadSurah(1);
  }

  Future<void> _loadSurah(int num) async {
    setState(() {
      _loading = true;
      _error = '';
      _ayatList = [];
      _selectedSurah = num;
      _showDropdown = false;
    });

    // Try APIs in order until one succeeds
    List<AyatData>? result;

    result ??= await _fetchFromEquranId(num);
    result ??= await _fetchFromAlquranCloud(num);
    result ??= await _fetchFromGadingDev(num);
    result ??= await _fetchFromMyQuranApi(num);

    // Last resort: use built-in fallback for Al-Fatihah
    if (result == null && num == 1) {
      result = _fatihahFallback;
    }

    setState(() {
      if (result != null && result.isNotEmpty) {
        _ayatList = result;
        _error = '';
      } else {
        _error = 'Gagal memuat ayat. Coba tekan tombol refresh atau periksa koneksi internet.';
      }
      _loading = false;
    });
  }

  /// API 1: equran.id (bahasa Indonesia, sangat stabil)
  Future<List<AyatData>?> _fetchFromEquranId(int num) async {
    try {
      final url = Uri.parse('https://equran.id/api/v2/surat/$num');
      final res = await http.get(url, headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final verses = data['data']['ayat'] as List;
        return verses.map<AyatData>((v) {
          return AyatData(
            number: (v['nomorAyat'] ?? v['nomor']) as int,
            arabic: v['teksArab'] as String? ?? '',
            latin: v['teksLatin'] as String? ?? '',
            translation: v['teksIndonesia'] as String? ?? '',
          );
        }).toList();
      }
    } catch (_) {}
    return null;
  }

  /// API 2: alquran.cloud (internasional, terpercaya)
  Future<List<AyatData>?> _fetchFromAlquranCloud(int num) async {
    try {
      // Fetch Arabic text
      final arabUrl = Uri.parse(
        'https://api.alquran.cloud/v1/surah/$num/quran-uthmani',
      );
      // Fetch Indonesian translation
      final transUrl = Uri.parse(
        'https://api.alquran.cloud/v1/surah/$num/id.indonesian',
      );

      final results = await Future.wait([
        http.get(arabUrl).timeout(const Duration(seconds: 12)),
        http.get(transUrl).timeout(const Duration(seconds: 12)),
      ]);

      if (results[0].statusCode == 200 && results[1].statusCode == 200) {
        final arabData = jsonDecode(results[0].body);
        final transData = jsonDecode(results[1].body);

        final arabAyat = arabData['data']['ayahs'] as List;
        final transAyat = transData['data']['ayahs'] as List;

        return List<AyatData>.generate(arabAyat.length, (i) {
          return AyatData(
            number: arabAyat[i]['numberInSurah'] as int,
            arabic: arabAyat[i]['text'] as String? ?? '',
            latin: '',
            translation: i < transAyat.length
                ? transAyat[i]['text'] as String? ?? ''
                : '',
          );
        });
      }
    } catch (_) {}
    return null;
  }

  /// API 3: quran.gading.dev (original, sebagai tertier)
  Future<List<AyatData>?> _fetchFromGadingDev(int num) async {
    try {
      final url = Uri.parse('https://quran.gading.dev/surah/$num');
      final res = await http.get(url).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final verses = data['data']['verses'] as List;
        return verses.map<AyatData>((v) {
          return AyatData(
            number: v['number']['inSurah'] as int,
            arabic: v['text']['arab'] as String? ?? '',
            latin: v['text']['transliteration']['en'] as String? ?? '',
            translation: v['translation']['id'] as String? ?? '',
          );
        }).toList();
      }
    } catch (_) {}
    return null;
  }

  /// API 4: quran-api-id (backup terakhir)
  Future<List<AyatData>?> _fetchFromMyQuranApi(int num) async {
    try {
      final url = Uri.parse(
        'https://quran-api-id.vercel.app/surahs/$num',
      );
      final res = await http.get(url, headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        // This API returns array directly or inside a key
        List verses;
        if (data is List) {
          verses = data;
        } else if (data['ayahs'] != null) {
          verses = data['ayahs'] as List;
        } else if (data['verses'] != null) {
          verses = data['verses'] as List;
        } else {
          return null;
        }
        return verses.asMap().entries.map<AyatData>((entry) {
          final i = entry.key;
          final v = entry.value;
          return AyatData(
            number: (v['number'] ?? v['nomorAyat'] ?? v['ayah'] ?? (i + 1)) as int,
            arabic: (v['arab'] ?? v['arabic'] ?? v['text'] ?? '') as String,
            latin: (v['latin'] ?? v['transliteration'] ?? '') as String,
            translation: (v['translation'] ?? v['arti'] ?? v['indonesian'] ?? '') as String,
          );
        }).toList();
      }
    } catch (_) {}
    return null;
  }

  static const List<AyatData> _fatihahFallback = [
    AyatData(
      number: 1,
      arabic: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
      latin: 'Bismillāhir-raḥmānir-raḥīm(i).',
      translation: 'Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang.',
    ),
    AyatData(
      number: 2,
      arabic: 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ',
      latin: 'Al-ḥamdu lillāhi rabbil-ʿālamīn(a).',
      translation: 'Segala puji bagi Allah, Tuhan semesta alam.',
    ),
    AyatData(
      number: 3,
      arabic: 'ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      latin: 'Ar-raḥmānir-raḥīm(i).',
      translation: 'Yang Maha Pengasih lagi Maha Penyayang.',
    ),
    AyatData(
      number: 4,
      arabic: 'مَٰلِكِ يَوْمِ ٱلدِّينِ',
      latin: 'Māliki yawmid-dīn(i).',
      translation: 'Pemilik hari pembalasan.',
    ),
    AyatData(
      number: 5,
      arabic: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
      latin: 'Iyyāka naʿbudu wa iyyāka nastaʿīn(u).',
      translation: 'Hanya kepada Engkau kami menyembah dan hanya kepada Engkau kami memohon pertolongan.',
    ),
    AyatData(
      number: 6,
      arabic: 'ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ',
      latin: 'Ihdinaṣ-ṣirāṭal-mustaqīm(a).',
      translation: 'Tunjukilah kami jalan yang lurus.',
    ),
    AyatData(
      number: 7,
      arabic: 'صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ',
      latin: 'Ṣirāṭal-lażīna anʿamta ʿalayhim, gayril-magḍūbi ʿalayhim wa laḍ-ḍāllīn(a).',
      translation: 'Yaitu jalan orang-orang yang telah Engkau beri nikmat, bukan jalan mereka yang dimurkai dan bukan pula jalan mereka yang sesat.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBgPrimary,
      body: Stack(
        children: [
          Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildTadabburBanner(),
                      const SizedBox(height: 12),
                      _buildPilihSurat(),
                      const SizedBox(height: 12),
                      _buildSurahCard(),
                      const SizedBox(height: 12),
                      _buildAyatList(),
                      // Arab HD badge
                      Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          margin: const EdgeInsets.only(top: 8, bottom: 4),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: kBluePrimary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: kBlueBright.withOpacity(0.4)),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.fullscreen, size: 12, color: kBlueAccent),
                              SizedBox(width: 4),
                              Text(
                                'Arab HD',
                                style: TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.w700,
                                  color: kBlueAccent, letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
              ),
            ],
          ),
          // Dropdown overlay
          if (_showDropdown) _buildDropdownOverlay(),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(context),
    );
  }

  // ── HEADER ──────────────────────────────────
  Widget _buildHeader(BuildContext context) {
    return Container(
      color: kBgPrimary.withOpacity(0.97),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 10,
        left: 16, right: 16, bottom: 12,
      ),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: kBorder)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: _hdrIcon(Icons.arrow_back_ios_new_rounded),
          ),
          const Expanded(
            child: Center(
              child: Text(
                'AL-QURAN',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                  color: kTextPrimary,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () => _showSearch(context),
            child: _hdrIcon(Icons.search_rounded),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () {},
            child: _hdrIcon(Icons.my_location_rounded),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _loadSurah(_selectedSurah),
            child: _hdrIcon(Icons.refresh_rounded),
          ),
        ],
      ),
    );
  }

  Widget _hdrIcon(IconData icon) {
    return Container(
      width: 34, height: 34,
      decoration: BoxDecoration(
        color: kBgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kBorder),
      ),
      child: Icon(icon, color: kTextSecondary, size: 16),
    );
  }

  // ── TADABBUR BANNER ─────────────────────────
  Widget _buildTadabburBanner() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1E40), Color(0xFF122060), Color(0xFF0A1840)],
        ),
        border: Border.all(color: kBorderBright),
        boxShadow: [
          BoxShadow(color: kBluePrimary.withOpacity(0.3), blurRadius: 20),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: const LinearGradient(colors: [kBlueDark, kBluePrimary]),
              border: Border.all(color: kBlueBright),
              boxShadow: [
                BoxShadow(color: kBluePrimary.withOpacity(0.4), blurRadius: 14),
              ],
            ),
            child: const Center(child: Text('📖', style: TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'BACA & TADABBUR',
                  style: TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w700,
                    color: kTextPrimary, letterSpacing: 1,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Search Surat · Quick Jump Ayat · Arab\nFullscreen HD',
                  style: TextStyle(fontSize: 10, color: kTextMuted, height: 1.5),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: kGold.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kGold.withOpacity(0.4)),
            ),
            child: const Text(
              'V2 API',
              style: TextStyle(
                fontSize: 9, fontWeight: FontWeight.w700,
                color: kGold, letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── PILIH SURAT ─────────────────────────────
  Widget _buildPilihSurat() {
    return GestureDetector(
      onTap: () => setState(() => _showDropdown = !_showDropdown),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: kBgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: kBluePrimary.withOpacity(0.15),
                border: Border.all(color: kBluePrimary.withOpacity(0.3)),
              ),
              child: const Icon(Icons.tune_rounded, color: kBluePrimary, size: 18),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Pilih Surat',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: kTextPrimary)),
                  SizedBox(height: 2),
                  Text('Atau klik ikon Search di atas',
                    style: TextStyle(fontSize: 10, color: kTextMuted)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: kBgCard2,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: kBorder),
              ),
              child: Row(
                children: [
                  Text(
                    '$_selectedSurah',
                    style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700, color: kTextPrimary,
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.arrow_drop_down, color: kTextMuted, size: 18),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── SURAH CARD ──────────────────────────────
  Widget _buildSurahCard() {
    final s = _currentSurah;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1A36), Color(0xFF102050), Color(0xFF091828)],
        ),
        border: Border.all(color: kBorderBright),
        boxShadow: [
          BoxShadow(color: kBluePrimary.withOpacity(0.3), blurRadius: 20),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: kBluePrimary.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kBluePrimary.withOpacity(0.5)),
                ),
                child: Text(
                  'SURAH ${s.number}',
                  style: const TextStyle(
                    fontSize: 9, fontWeight: FontWeight.w700,
                    color: kBlueAccent, letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                s.nameEn,
                style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w700,
                  color: kTextPrimary, letterSpacing: 2,
                ),
              ),
              const Spacer(),
              _surahActBtn(Icons.search),
              const SizedBox(width: 6),
              _surahActBtn(Icons.my_location),
              const SizedBox(width: 6),
              _surahActBtn(Icons.fullscreen),
            ],
          ),
          const SizedBox(height: 12),
          // Arabic name
          Text(
            s.nameArab,
            textDirection: TextDirection.rtl,
            style: const TextStyle(
              fontSize: 28,
              color: kGoldLight,
              fontFamily: 'Arial',
              shadows: [Shadow(color: Color(0x4DF0A030), blurRadius: 20)],
            ),
          ),
          const SizedBox(height: 12),
          const Divider(color: kBorder, height: 1),
          const SizedBox(height: 12),
          Row(
            children: [
              _surahTag(s.place),
              const SizedBox(width: 8),
              _surahTag('${s.ayatCount} ayat'),
              const SizedBox(width: 8),
              _surahTag('Arti: ${s.meaning}'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _surahActBtn(IconData icon) {
    return Container(
      width: 30, height: 30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: kBluePrimary.withOpacity(0.15),
        border: Border.all(color: kBluePrimary.withOpacity(0.3)),
      ),
      child: Icon(icon, color: kTextSecondary, size: 14),
    );
  }

  Widget _surahTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: kBluePrimary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kBluePrimary.withOpacity(0.25)),
      ),
      child: Text(
        text,
        style: const TextStyle(fontSize: 10, color: kTextSecondary, fontWeight: FontWeight.w600),
      ),
    );
  }

  // ── AYAT LIST ────────────────────────────────
  Widget _buildAyatList() {
    if (_loading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 40),
          child: Column(
            children: [
              CircularProgressIndicator(color: kBlueBright, strokeWidth: 2),
              SizedBox(height: 16),
              Text(
                'Memuat ayat...',
                style: TextStyle(fontSize: 13, color: kTextMuted),
              ),
              SizedBox(height: 6),
              Text(
                'Mencoba beberapa server Al-Quran',
                style: TextStyle(fontSize: 11, color: kTextMuted),
              ),
            ],
          ),
        ),
      );
    }

    if (_error.isNotEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 40),
          child: Column(
            children: [
              const Icon(Icons.signal_wifi_connected_no_internet_4_rounded,
                  color: kTextMuted, size: 48),
              const SizedBox(height: 12),
              Text(
                _error,
                textAlign: TextAlign.center,
                style: const TextStyle(color: kTextMuted, fontSize: 13),
              ),
              const SizedBox(height: 8),
              const Text(
                'Sudah dicoba 4 server Al-Quran',
                style: TextStyle(color: kTextMuted, fontSize: 11),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => _loadSurah(_selectedSurah),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [kBlueDark, kBluePrimary],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: kBlueBright),
                    boxShadow: [
                      BoxShadow(
                        color: kBluePrimary.withOpacity(0.4),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh_rounded, color: kTextPrimary, size: 16),
                      SizedBox(width: 8),
                      Text(
                        'Coba Lagi',
                        style: TextStyle(
                          color: kTextPrimary,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: _ayatList.map((a) => _buildAyatCard(a)).toList(),
    );
  }

  Widget _buildAyatCard(AyatData a) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kBgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header: Ayat number + bookmark
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: kGold.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kGold.withOpacity(0.3)),
                ),
                child: Text(
                  'Ayat ${a.number}',
                  style: const TextStyle(
                    fontSize: 10, fontWeight: FontWeight.w700,
                    color: kGold, letterSpacing: 0.5,
                  ),
                ),
              ),
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: kBluePrimary.withOpacity(0.1),
                  border: Border.all(color: kBluePrimary.withOpacity(0.2)),
                ),
                child: const Icon(Icons.bookmark_border, color: kTextMuted, size: 14),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Arabic text (RTL)
          Directionality(
            textDirection: TextDirection.rtl,
            child: Text(
              a.arabic,
              style: const TextStyle(
                fontSize: 22,
                color: kTextPrimary,
                height: 2,
                fontFamily: 'Arial',
              ),
              textAlign: TextAlign.right,
            ),
          ),
          const SizedBox(height: 12),
          // Latin
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: kBluePrimary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kBluePrimary.withOpacity(0.15)),
            ),
            child: Text(
              a.latin,
              style: const TextStyle(
                fontSize: 12,
                color: kTextSecondary,
                fontStyle: FontStyle.italic,
                height: 1.6,
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Translation
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: kBgCard2,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kBorder),
            ),
            child: Text(
              a.translation,
              style: const TextStyle(
                fontSize: 12, color: kTextSecondary, height: 1.6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── DROPDOWN SURAT ───────────────────────────
  Widget _buildDropdownOverlay() {
    return Positioned(
      top: 0, right: 0, bottom: 0,
      child: GestureDetector(
        onTap: () => setState(() => _showDropdown = false),
        child: Container(
          color: Colors.transparent,
          width: MediaQuery.of(context).size.width,
          child: Align(
            alignment: Alignment.centerRight,
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: const Color(0xFF081424).withOpacity(0.98),
                border: const Border(left: BorderSide(color: kBorder)),
              ),
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: 114,
                itemBuilder: (_, i) {
                  final num = i + 1;
                  final selected = num == _selectedSurah;
                  return GestureDetector(
                    onTap: () => _loadSurah(num),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: selected
                            ? kBluePrimary.withOpacity(0.15)
                            : Colors.transparent,
                        border: const Border(
                          bottom: BorderSide(color: Color(0x1A1E50B4)),
                        ),
                      ),
                      child: Text(
                        '$num',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: selected ? kBlueAccent : kTextSecondary,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── SEARCH ────────────────────────────────────
  void _showSearch(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kBgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _SearchSheet(
        onSelect: (num) {
          Navigator.pop(context);
          _loadSurah(num);
        },
      ),
    );
  }

  // ── BOTTOM NAV ───────────────────────────────
  Widget _buildBottomNav(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: kBgPrimary,
        border: Border(top: BorderSide(color: kBorder)),
      ),
      child: SafeArea(
        child: Row(
          children: [
            _navItem(Icons.home_rounded, 'Home', false,
                () => Navigator.pop(context)),
            _navItem(Icons.menu_book_rounded, 'Al-Quran', true, () {}),
            _navItem(Icons.build_rounded, 'Tools', false, () {}),
          ],
        ),
      ),
    );
  }

  Widget _navItem(IconData icon, String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          color: Colors.transparent,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: active ? kBlueBright : kTextMuted, size: 22),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w600,
                  color: active ? kBlueBright : kTextMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SEARCH BOTTOM SHEET
// ─────────────────────────────────────────────
class _SearchSheet extends StatefulWidget {
  final void Function(int) onSelect;
  const _SearchSheet({required this.onSelect});

  @override
  State<_SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<_SearchSheet> {
  String _query = '';

  List<SurahInfo> get _filtered => kSurahList
      .where((s) =>
          s.nameEn.contains(_query.toUpperCase()) ||
          s.number.toString().contains(_query) ||
          s.meaning.toLowerCase().contains(_query.toLowerCase()))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            height: 4, width: 40,
            decoration: BoxDecoration(
              color: kBorder, borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'CARI SURAT',
            style: TextStyle(
              fontSize: 13, fontWeight: FontWeight.w700,
              color: kTextPrimary, letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            autofocus: true,
            onChanged: (v) => setState(() => _query = v),
            style: const TextStyle(color: kTextPrimary, fontSize: 14),
            decoration: InputDecoration(
              hintText: 'Nama atau nomor surah...',
              hintStyle: const TextStyle(color: kTextMuted, fontSize: 13),
              prefixIcon: const Icon(Icons.search, color: kTextMuted, size: 18),
              filled: true,
              fillColor: kBgCard2,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: kBorder),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: kBorder),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: kBlueBright),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              itemCount: _filtered.length,
              itemBuilder: (_, i) {
                final s = _filtered[i];
                return GestureDetector(
                  onTap: () => widget.onSelect(s.number),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: kBgCard2,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: kBorder),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 32, height: 32,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: kBluePrimary.withOpacity(0.15),
                            border: Border.all(color: kBluePrimary.withOpacity(0.3)),
                          ),
                          child: Center(
                            child: Text(
                              '${s.number}',
                              style: const TextStyle(
                                fontSize: 11, fontWeight: FontWeight.w700,
                                color: kBlueAccent,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                s.nameEn,
                                style: const TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w700,
                                  color: kTextPrimary,
                                ),
                              ),
                              Text(
                                '${s.place} · ${s.ayatCount} ayat · ${s.meaning}',
                                style: const TextStyle(
                                  fontSize: 10, color: kTextMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          s.nameArab,
                          textDirection: TextDirection.rtl,
                          style: const TextStyle(
                            fontSize: 16, color: kGoldLight, fontFamily: 'Arial',
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
