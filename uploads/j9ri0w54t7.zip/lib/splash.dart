import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _skipFadeController;
  late Animation<double> _skipFadeAnimation;
  bool _fadeOutStarted = false;
  bool _showSkipButton = false;
  bool _navigated = false;
  Timer? _skipTimer;
  AudioPlayer? _bgPlayer; // 🎵 musik dashboard, di-load dari splash

  @override
  void initState() {
    super.initState();

    // ✅ FIX: Init AnimationController di initState, bukan di dalam callback
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    _skipFadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _skipFadeAnimation = CurvedAnimation(
      parent: _skipFadeController,
      curve: Curves.easeIn,
    );

    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(false);
        _videoController.setVolume(1.0);
        _videoController.play();

        // 🎵 mulai load musik dashboard sejak splash
        _initBgMusic();

        // Tampilkan tombol SKIP setelah 3 detik
        _skipTimer = Timer(const Duration(seconds: 3), () {
          if (mounted) {
            setState(() => _showSkipButton = true);
            _skipFadeController.forward();
          }
        });

        _videoController.addListener(_onVideoUpdate);
      });
  }

  void _onVideoUpdate() {
    if (!mounted) return;
    final position = _videoController.value.position;
    final duration = _videoController.value.duration;

    // ✅ FIX: Cek duration > Duration.zero agar tidak null/empty
    if (duration == Duration.zero) return;

    if (position >= duration - const Duration(seconds: 1) && !_fadeOutStarted) {
      _fadeOutStarted = true;
      _fadeController.forward();
    }

    if (position >= duration) {
      _navigateToDashboard();
    }
  }

  // 🎵 Load dan siapkan musik dari asset lokal saat splash masih jalan
  Future<void> _initBgMusic() async {
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration(
        avAudioSessionCategory: AVAudioSessionCategory.playback,
        androidAudioAttributes: AndroidAudioAttributes(
          contentType: AndroidAudioContentType.music,
          usage: AndroidAudioUsage.media,
        ),
        androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
        androidWillPauseWhenDucked: false,
      ));

      _bgPlayer = AudioPlayer();
      // ✅ FIX: Gunakan asset lokal agar pasti tersedia (tidak tergantung internet)
      await _bgPlayer!.setAudioSource(
        AudioSource.asset('assets/audio/dashboard_music.mp3'),
      );
      await _bgPlayer!.setLoopMode(LoopMode.one);
      await _bgPlayer!.setVolume(0.8);
      // Jangan play dulu — akan di-play saat masuk dashboard
      debugPrint('🎵 Musik berhasil di-load dari splash (asset lokal)');
    } catch (e) {
      debugPrint('🎵 Gagal load musik di splash: $e');
      _bgPlayer = null;
    }
  }

  void _navigateToDashboard() {
    // ✅ FIX: Guard double-navigation
    if (_navigated || !mounted) return;
    _navigated = true;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
          audioPlayer: _bgPlayer, // 🎵 pass player yang sudah siap
        ),
      ),
    );
  }

  @override
  void dispose() {
    _skipTimer?.cancel();
    _videoController.removeListener(_onVideoUpdate);
    _videoController.dispose();
    _fadeController.dispose();
    _skipFadeController.dispose();
    // _bgPlayer TIDAK di-dispose di sini karena dipakai oleh DashboardPage
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        alignment: Alignment.center,
        children: [
          // Video di dalam Card dengan efek glass
          if (_videoController.value.isInitialized)
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: AspectRatio(
                      aspectRatio: _videoController.value.aspectRatio,
                      child: VideoPlayer(_videoController),
                    ),
                  ),
                ),
              ),
            )
          else
            const Center(child: CircularProgressIndicator()),

          // Teks Expolion
          Positioned(
            bottom: 80,
            child: Text(
              "Expolion",
              style: TextStyle(
                fontSize: 42,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 3,
                shadows: [
                  Shadow(
                    color: const Color(0xFFFFD700).withOpacity(0.9),
                    blurRadius: 10,
                    offset: const Offset(2, 2),
                  ),
                  Shadow(
                    color: Colors.black.withOpacity(0.8),
                    blurRadius: 15,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
            ),
          ),

          // Fade out effect
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
              child: Container(color: Colors.black),
            ),

          // Tombol SKIP — muncul setelah 3 detik
          if (_showSkipButton)
            Positioned(
              top: 52,
              right: 20,
              child: FadeTransition(
                opacity: _skipFadeAnimation,
                child: GestureDetector(
                  onTap: _navigateToDashboard,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.55),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFFFD700).withOpacity(0.7),
                        width: 1.2,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Text(
                          'SKIP',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.5,
                          ),
                        ),
                        SizedBox(width: 6),
                        Icon(
                          Icons.skip_next_rounded,
                          color: const Color(0xFFFFD700),
                          size: 18,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
