import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

// ═══════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════

class ChatMessage {
  final String id;
  final String username;
  final String role;
  final String text;
  final DateTime time;
  final bool isMe;
  final bool isSystem;

  ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.text,
    required this.time,
    required this.isMe,
    this.isSystem = false,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json, String myUsername) {
    return ChatMessage(
      id: json['id']?.toString() ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      username: json['username'] ?? 'Unknown',
      role: json['role'] ?? 'user',
      text: json['message'] ?? json['text'] ?? '',
      time: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'].toString()) ?? DateTime.now()
          : DateTime.now(),
      isMe: (json['username'] ?? '') == myUsername,
    );
  }

  factory ChatMessage.system(String text) {
    return ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      username: 'system',
      role: 'system',
      text: text,
      time: DateTime.now(),
      isMe: false,
      isSystem: true,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// PAGE
// ═══════════════════════════════════════════════════════════════

class GlobalChatPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const GlobalChatPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage>
    with TickerProviderStateMixin {
  // ── WebSocket ────────────────────────────────────────────────
  WebSocketChannel? _channel;
  StreamSubscription? _sub;
  bool _connected = false;
  bool _connecting = true;
  int _onlineCount = 0;
  int _reconnectAttempts = 0;
  Timer? _reconnectTimer;
  Timer? _pingTimer;

  // ── Messages ─────────────────────────────────────────────────
  final List<ChatMessage> _messages = [];
  final ScrollController _scrollCtrl = ScrollController();
  final TextEditingController _inputCtrl = TextEditingController();
  bool _sending = false;
  bool _showScrollBtn = false;

  // ── Animation ────────────────────────────────────────────────
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // ── Theme ─────────────────────────────────────────────────────
  static const Color _bg       = Color(0xFF0D0900);
  static const Color _card     = Color(0xFF201900);
  static const Color _cardDark = Color(0xFF1A1400);
  static const Color _blue     = Color(0xFFFFD700);
  static const Color _blueDark = Color(0xFFB8860B);
  static const String _wsUrl   = 'ws://miunnst.site:4035';

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _scrollCtrl.addListener(() {
      final atBottom = _scrollCtrl.position.pixels >=
          _scrollCtrl.position.maxScrollExtent - 80;
      if (_showScrollBtn == atBottom) {
        setState(() => _showScrollBtn = !atBottom);
      }
    });

    _connect();
  }

  // ── Connect ──────────────────────────────────────────────────
  void _connect() {
    if (!mounted) return;
    setState(() {
      _connecting = true;
      _connected = false;
    });

    try {
      _channel?.sink.close();
      _sub?.cancel();
      _pingTimer?.cancel();

      _channel = WebSocketChannel.connect(Uri.parse(_wsUrl));

      // Handshake: join global chat room
      _channel!.sink.add(jsonEncode({
        'type': 'joinGlobalChat',
        'key': widget.sessionKey,
        'username': widget.username,
        'role': widget.role,
      }));

      // Minta history
      _channel!.sink.add(jsonEncode({
        'type': 'getChatHistory',
        'key': widget.sessionKey,
      }));

      _sub = _channel!.stream.listen(
        _onData,
        onError: (_) => _handleDisconnect(),
        onDone: () => _handleDisconnect(),
      );

      // Ping setiap 25 detik agar koneksi tidak di-drop server
      _pingTimer = Timer.periodic(const Duration(seconds: 25), (_) {
        if (_connected) {
          _channel?.sink.add(jsonEncode({'type': 'ping'}));
        }
      });

      if (mounted) {
        setState(() {
          _connected = true;
          _connecting = false;
          _reconnectAttempts = 0;
        });
      }
    } catch (_) {
      _handleDisconnect();
    }
  }

  void _onData(dynamic raw) {
    if (!mounted) return;
    try {
      final data = jsonDecode(raw.toString());
      final type = data['type']?.toString() ?? '';

      setState(() {
        switch (type) {
          // Statistik online
          case 'chatStats':
          case 'stats':
            _onlineCount =
                data['chatOnline'] ?? data['onlineUsers'] ?? _onlineCount;
            break;

          // Satu pesan baru dari siapapun
          case 'globalMessage':
          case 'chatMessage':
            final msg = ChatMessage.fromJson(data, widget.username);
            if (msg.text.isNotEmpty) {
              _messages.add(msg);
              _trimMessages();
            }
            break;

          // History awal
          case 'chatHistory':
            final List list =
                data['messages'] ?? data['history'] ?? [];
            _messages.clear();
            for (final m in list) {
              final msg = ChatMessage.fromJson(
                  Map<String, dynamic>.from(m), widget.username);
              if (msg.text.isNotEmpty) _messages.add(msg);
            }
            break;

          // User join/left
          case 'userJoined':
            _onlineCount = data['onlineCount'] ?? _onlineCount;
            _messages.add(ChatMessage.system(
                '${data['username'] ?? '?'} bergabung ke chat 👋'));
            break;
          case 'userLeft':
            _onlineCount = data['onlineCount'] ?? _onlineCount;
            _messages.add(
                ChatMessage.system('${data['username'] ?? '?'} keluar dari chat'));
            break;

          case 'pong':
            break; // keep-alive response
        }
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!_showScrollBtn) _scrollToBottom();
      });
    } catch (_) {}
  }

  void _handleDisconnect() {
    if (!mounted) return;
    _pingTimer?.cancel();
    setState(() {
      _connected = false;
      _connecting = false;
    });

    // Auto-reconnect max 6x dengan delay bertahap
    if (_reconnectAttempts < 6) {
      final delay = Duration(seconds: 2 + _reconnectAttempts * 3);
      _reconnectTimer?.cancel();
      _reconnectTimer = Timer(delay, () {
        if (mounted) {
          _reconnectAttempts++;
          _connect();
        }
      });
    }
  }

  void _trimMessages() {
    if (_messages.length > 200) {
      _messages.removeRange(0, _messages.length - 200);
    }
  }

  // ── Send ─────────────────────────────────────────────────────
  Future<void> _sendMessage() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || !_connected || _sending) return;
    if (text.length > 500) {
      _snack('Pesan maksimal 500 karakter', isError: true);
      return;
    }

    setState(() => _sending = true);
    _inputCtrl.clear();

    try {
      _channel!.sink.add(jsonEncode({
        'type': 'sendGlobalMessage',
        'key': widget.sessionKey,
        'username': widget.username,
        'role': widget.role,
        'message': text,
      }));

      // Optimistic UI — tampil langsung tanpa tunggu server echo
      setState(() {
        _messages.add(ChatMessage(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          username: widget.username,
          role: widget.role,
          text: text,
          time: DateTime.now(),
          isMe: true,
        ));
        _trimMessages();
      });

      WidgetsBinding.instance
          .addPostFrameCallback((_) => _scrollToBottom());
    } catch (_) {
      _snack('Gagal mengirim pesan', isError: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _scrollToBottom({bool animated = true}) {
    if (!_scrollCtrl.hasClients) return;
    if (animated) {
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    } else {
      _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
    }
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(fontFamily: 'Rajdhani')),
      backgroundColor:
          (isError ? Colors.red : Colors.green).withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 2),
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  // ── Helpers ──────────────────────────────────────────────────
  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'creator':
        return Colors.red.shade400;
      case 'owner':
        return const Color(0xFFFFD700);
      case 'admin':
        return Colors.green.shade400;
      case 'premium':
        return Colors.orange.shade400;
      case 'system':
        return Colors.white30;
      default:
        return const Color(0xFFFFEC6E);
    }
  }

  String _roleLabel(String role) {
    switch (role.toLowerCase()) {
      case 'creator':    return '👑 CREATOR';
      case 'owner':      return '⚡ OWNER';
      case 'admin':     return '🏪 ADMIN';
      case 'premium':  return '💎 PREMIUM';
      default:         return '👤 USER';
    }
  }

  String _timeStr(DateTime t) {
    final now = DateTime.now();
    final diff = now.difference(t);
    if (diff.inSeconds < 60) return 'baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
    if (t.day == now.day) {
      return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    }
    return '${t.day}/${t.month} '
        '${t.hour.toString().padLeft(2, '0')}:'
        '${t.minute.toString().padLeft(2, '0')}';
  }

  // ── BUILD ────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: Stack(
              children: [
                _buildMessageList(),
                // Scroll-to-bottom FAB
                if (_showScrollBtn)
                  Positioned(
                    bottom: 12,
                    right: 12,
                    child: GestureDetector(
                      onTap: _scrollToBottom,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _blue.withOpacity(0.9),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: _blue.withOpacity(0.4),
                              blurRadius: 10,
                            )
                          ],
                        ),
                        child: const Icon(Icons.keyboard_arrow_down,
                            color: Colors.white, size: 22),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }

  // ── Header ───────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: BoxDecoration(
        color: _cardDark,
        border:
            Border(bottom: BorderSide(color: _blue.withOpacity(0.2))),
        boxShadow: [
          BoxShadow(
            color: _blue.withOpacity(0.07),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          // Ikon
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_blueDark, _blue],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                    color: _blue.withOpacity(0.4), blurRadius: 8)
              ],
            ),
            child: const Icon(Icons.forum_rounded,
                color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),

          // Title & status
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Global Chat',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    // Status dot
                    AnimatedBuilder(
                      animation: _pulseAnim,
                      builder: (_, __) => Opacity(
                        opacity:
                            _connected ? _pulseAnim.value : 0.3,
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: _connected
                                ? Colors.green
                                : Colors.red,
                            shape: BoxShape.circle,
                            boxShadow: _connected
                                ? [
                                    BoxShadow(
                                      color: Colors.green
                                          .withOpacity(0.5),
                                      blurRadius: 4,
                                    )
                                  ]
                                : null,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _connecting
                          ? 'Menghubungkan...'
                          : _connected
                              ? '$_onlineCount online'
                              : 'Terputus — mencoba ulang...',
                      style: TextStyle(
                        color: _connected
                            ? Colors.green.shade300
                            : Colors.white38,
                        fontSize: 11,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Reconnect button
          if (!_connected && !_connecting)
            GestureDetector(
              onTap: () {
                _reconnectAttempts = 0;
                _connect();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: _blue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: _blue.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.refresh,
                        color: _blue, size: 14),
                    const SizedBox(width: 4),
                    Text('Sambung',
                        style: TextStyle(
                          color: _blue,
                          fontSize: 11,
                          fontFamily: 'Rajdhani',
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── Message List ─────────────────────────────────────────────
  Widget _buildMessageList() {
    if (_connecting && _messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: _blue),
            const SizedBox(height: 16),
            Text('Menghubungkan ke Global Chat...',
                style: TextStyle(
                    color: Colors.white38,
                    fontFamily: 'Rajdhani',
                    fontSize: 13)),
          ],
        ),
      );
    }

    if (_messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: _card,
                shape: BoxShape.circle,
                border: Border.all(
                    color: _blue.withOpacity(0.2)),
              ),
              child: Icon(Icons.chat_bubble_outline_rounded,
                  color: _blue.withOpacity(0.5), size: 48),
            ),
            const SizedBox(height: 20),
            const Text('Belum ada pesan',
                style: TextStyle(
                    color: Colors.white54,
                    fontSize: 16,
                    fontFamily: 'Rajdhani')),
            const SizedBox(height: 8),
            const Text('Jadilah yang pertama memulai obrolan!',
                style: TextStyle(
                    color: Colors.white30,
                    fontSize: 12,
                    fontFamily: 'Rajdhani')),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollCtrl,
      padding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      itemCount: _messages.length,
      itemBuilder: (_, i) {
        final msg = _messages[i];

        // System notice
        if (msg.isSystem) return _buildSystemNotice(msg.text);

        final prev = i > 0 ? _messages[i - 1] : null;
        final showHeader = prev == null ||
            prev.username != msg.username ||
            msg.time.difference(prev.time).inMinutes > 5;

        return msg.isMe
            ? _buildMyBubble(msg, showHeader)
            : _buildOtherBubble(msg, showHeader);
      },
    );
  }

  Widget _buildSystemNotice(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(
              horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white12),
          ),
          child: Text(text,
              style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 11,
                  fontFamily: 'Rajdhani')),
        ),
      ),
    );
  }

  // Bubble pesan sendiri — kanan
  Widget _buildMyBubble(ChatMessage msg, bool showHeader) {
    return Padding(
      padding: EdgeInsets.only(
          bottom: 3, top: showHeader ? 10 : 2, left: 64),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (showHeader)
            Padding(
              padding: const EdgeInsets.only(bottom: 4, right: 4),
              child: Text(_timeStr(msg.time),
                  style: const TextStyle(
                      color: Colors.white24,
                      fontSize: 10,
                      fontFamily: 'Rajdhani')),
            ),
          GestureDetector(
            onLongPress: () => _copyMsg(msg.text),
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_blueDark, _blue],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(18),
                  topRight: Radius.circular(18),
                  bottomLeft: Radius.circular(18),
                  bottomRight: Radius.circular(4),
                ),
                boxShadow: [
                  BoxShadow(
                    color: _blue.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  )
                ],
              ),
              child: Text(msg.text,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      height: 1.4)),
            ),
          ),
        ],
      ),
    );
  }

  // Bubble pesan orang lain — kiri
  Widget _buildOtherBubble(ChatMessage msg, bool showHeader) {
    final rc = _roleColor(msg.role);

    return Padding(
      padding: EdgeInsets.only(
          bottom: 3, top: showHeader ? 10 : 2, right: 64),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (showHeader) ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Avatar
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: rc.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: rc.withOpacity(0.5), width: 1.5),
                  ),
                  child: Center(
                    child: Text(
                      msg.username.isNotEmpty
                          ? msg.username[0].toUpperCase()
                          : '?',
                      style: TextStyle(
                          color: rc,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Rajdhani'),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(msg.username,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Rajdhani')),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: rc.withOpacity(0.15),
                              borderRadius:
                                  BorderRadius.circular(5),
                              border: Border.all(
                                  color: rc.withOpacity(0.3)),
                            ),
                            child: Text(_roleLabel(msg.role),
                                style: TextStyle(
                                    color: rc,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Rajdhani',
                                    letterSpacing: 0.3)),
                          ),
                          const SizedBox(width: 6),
                          Text(_timeStr(msg.time),
                              style: const TextStyle(
                                  color: Colors.white24,
                                  fontSize: 10,
                                  fontFamily: 'Rajdhani')),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
          ],
          Padding(
            padding: const EdgeInsets.only(left: 42),
            child: GestureDetector(
              onLongPress: () => _copyMsg(msg.text),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(4),
                    topRight: Radius.circular(18),
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                  border: Border.all(
                      color: rc.withOpacity(0.15), width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    )
                  ],
                ),
                child: Text(msg.text,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        height: 1.4)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _copyMsg(String text) {
    Clipboard.setData(ClipboardData(text: text));
    _snack('Pesan disalin ✓');
  }

  // ── Input Bar ────────────────────────────────────────────────
  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 10,
        bottom:
            MediaQuery.of(context).viewInsets.bottom > 0 ? 10 : 16,
      ),
      decoration: BoxDecoration(
        color: _cardDark,
        border:
            Border(top: BorderSide(color: _blue.withOpacity(0.15))),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, -3),
          )
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Text field
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: _connected
                      ? _blue.withOpacity(0.3)
                      : Colors.white12,
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const SizedBox(width: 16),
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      enabled: _connected,
                      maxLines: 4,
                      minLines: 1,
                      maxLength: 500,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontFamily: 'Rajdhani'),
                      decoration: InputDecoration(
                        hintText: _connected
                            ? 'Tulis pesan...'
                            : 'Tidak terhubung...',
                        hintStyle: TextStyle(
                            color: Colors.white.withOpacity(0.25),
                            fontSize: 13,
                            fontFamily: 'Rajdhani'),
                        border: InputBorder.none,
                        counterText: '',
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 13),
                      ),
                      onSubmitted: (_) => _sendMessage(),
                      textInputAction: TextInputAction.send,
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),

          // Kirim button
          GestureDetector(
            onTap: _connected && !_sending ? _sendMessage : null,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                gradient: _connected
                    ? const LinearGradient(
                        colors: [_blueDark, _blue],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
                color: _connected ? null : Colors.white12,
                shape: BoxShape.circle,
                boxShadow: _connected
                    ? [
                        BoxShadow(
                          color: _blue.withOpacity(0.45),
                          blurRadius: 10,
                          spreadRadius: 1,
                        )
                      ]
                    : null,
              ),
              child: _sending
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.send_rounded,
                      color: Colors.white, size: 22),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _reconnectTimer?.cancel();
    _pingTimer?.cancel();
    _sub?.cancel();
    _channel?.sink.close(status.goingAway);
    _pulseCtrl.dispose();
    _scrollCtrl.dispose();
    _inputCtrl.dispose();
    super.dispose();
  }
}
