import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'bug_sender.dart';
import 'manage_sender.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'global_chat_page.dart';
import 'alquran_page.dart';

// ═══════════════════════════════════════════════════════════════
// PRAYER TIME — Model & Data (Dashboard)
// ═══════════════════════════════════════════════════════════════

enum _ZonaWaktu { wib, wita, wit }

extension _ZonaWaktuExt on _ZonaWaktu {
  String get label {
    switch (this) {
      case _ZonaWaktu.wib: return 'WIB';
      case _ZonaWaktu.wita: return 'WITA';
      case _ZonaWaktu.wit: return 'WIT';
    }
  }
  int get utcOffset {
    switch (this) {
      case _ZonaWaktu.wib: return 7;
      case _ZonaWaktu.wita: return 8;
      case _ZonaWaktu.wit: return 9;
    }
  }
  String get keterangan {
    switch (this) {
      case _ZonaWaktu.wib: return 'Waktu Indonesia Barat';
      case _ZonaWaktu.wita: return 'Waktu Indonesia Tengah';
      case _ZonaWaktu.wit: return 'Waktu Indonesia Timur';
    }
  }
}

class _WaktuShalat {
  final String nama;
  final String ikon;
  final int jamWIB;
  final int menitWIB;

  const _WaktuShalat({
    required this.nama,
    required this.ikon,
    required this.jamWIB,
    required this.menitWIB,
  });

  int jamZona(_ZonaWaktu zona) {
    int jam = jamWIB + (zona.utcOffset - 7);
    if (jam >= 24) jam -= 24;
    if (jam < 0) jam += 24;
    return jam;
  }

  String formatWaktu(_ZonaWaktu zona) {
    final jam = jamZona(zona);
    return '${jam.toString().padLeft(2, '0')}:${menitWIB.toString().padLeft(2, '0')}';
  }
}

const List<_WaktuShalat> _daftarShalatDashboard = [
  _WaktuShalat(nama: 'Subuh',   ikon: '🌙', jamWIB: 4,  menitWIB: 30),
  _WaktuShalat(nama: 'Dzuhur',  ikon: '☀️', jamWIB: 12, menitWIB: 0),
  _WaktuShalat(nama: 'Ashar',   ikon: '🌤', jamWIB: 15, menitWIB: 15),
  _WaktuShalat(nama: 'Maghrib', ikon: '🌅', jamWIB: 18, menitWIB: 0),
  _WaktuShalat(nama: 'Isya',    ikon: '🌃', jamWIB: 19, menitWIB: 15),
];

// ═══════════════════════════════════════════════════════════════

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final AudioPlayer? audioPlayer; // 🎵 player dari splash

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.audioPlayer,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedTabIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // 🎵 Music Player
  AudioPlayer? _audioPlayer; // ✅ FIX: nullable agar aman sebelum _initMusic selesai
  bool _isMusicPlaying = false;
  bool _isMuted = false;

  // Prayer Time State
  _ZonaWaktu _zonaAktif = _ZonaWaktu.wib;
  late DateTime _waktuUtc;
  late Timer _prayerTimer;

  // Warna tema hitam biru
  final Color primaryDark = Color(0xFF0D0900);
  final Color primaryBlue = Color(0xFFB8860B);
  final Color accentBlue = Color(0xFFFFD700);
  final Color lightBlue = Color(0xFFFFEC6E);
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardDark = Color(0xFF201900);
  final Color cardDarker = Color(0xFF1A1400);
  final Color blueGradientStart = Color(0xFFB8860B);
  final Color blueGradientEnd = Color(0xFFFFD700);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    // Initialize prayer time clock
    _waktuUtc = DateTime.now().toUtc();
    _prayerTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _waktuUtc = DateTime.now().toUtc());
    });

    _initAndroidIdAndConnect();
    _initMusic();
  }

  // ═══════════════════════════════════════════════════════════════
  // 🎵 MUSIC PLAYER
  // ═══════════════════════════════════════════════════════════════

  Future<void> _initMusic() async {
    // ✅ Jika player sudah disiapkan dari splash screen, langsung pakai
    if (widget.audioPlayer != null) {
      _audioPlayer = widget.audioPlayer!;
      try {
        await _audioPlayer!.play();
        if (mounted) setState(() => _isMusicPlaying = true);
      } catch (e) {
        debugPrint('Play from splash error: $e');
        await _initFallbackPlayer();
      }
      return;
    }
    await _initFallbackPlayer();
  }

  Future<void> _initFallbackPlayer() async {
    try {
      final player = AudioPlayer();
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration(
        avAudioSessionCategory: AVAudioSessionCategory.playback,
        androidAudioAttributes: AndroidAudioAttributes(
          contentType: AndroidAudioContentType.music,
          usage: AndroidAudioUsage.media,
        ),
        androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
        androidWillPauseWhenDucked: false,
      ));
      // ✅ FIX: Gunakan asset lokal agar tidak tergantung koneksi internet
      await player.setAudioSource(
        AudioSource.asset('assets/audio/dashboard_music.mp3'),
      );
      await player.setLoopMode(LoopMode.one);
      await player.setVolume(0.8);
      await player.play();
      if (mounted) {
        setState(() {
          _audioPlayer = player;
          _isMusicPlaying = true;
        });
      } else {
        await player.dispose();
      }
    } catch (e) {
      debugPrint('Music fallback error: $e');
    }
  }

  Future<void> _toggleMute() async {
    if (_audioPlayer == null) return; // ✅ FIX: guard nullable
    if (_isMuted) {
      await _audioPlayer!.setVolume(0.5);
      setState(() => _isMuted = false);
    } else {
      await _audioPlayer!.setVolume(0.0);
      setState(() => _isMuted = true);
    }
  }

  Future<void> _togglePlayPause() async {
    if (_audioPlayer == null) return; // ✅ FIX: guard nullable
    if (_isMusicPlaying) {
      await _audioPlayer!.pause();
      setState(() => _isMusicPlaying = false);
    } else {
      await _audioPlayer!.play();
      setState(() => _isMusicPlaying = true);
    }
  }
  // ═══════════════════════════════════════════════════════════════

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('ws://miunnst.site:4035'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardDarker,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired", style: TextStyle(color: accentBlue, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: accentGrey)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: accentBlue, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _onTabTapped(int index) {
    setState(() {
      _selectedTabIndex = index;
      if (index == 0) {
        // Tab Home: built dynamically via _buildCurrentPage()
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      }
    });
  }

  void _onDrawerItemSelected(int index) {
    setState(() {
      _selectedTabIndex = -1; // FIX: keluar dari tab 0 agar _selectedPage ditampilkan
      if (index == 3) _selectedPage = NikCheckerPage();
      else if (index == 4) _selectedPage = ChangePasswordPage(username: username, sessionKey: sessionKey);
      else if (index == 5) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 6) _selectedPage = AdminPage(sessionKey: sessionKey, role: role);
    });
  }

  Widget _buildNewsPage() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Section
            _buildHeaderSection(),

            const SizedBox(height: 24),

            // News Section
            _buildNewsSection(),

            const SizedBox(height: 24),

            // Feature Buttons Grid
            _buildFeatureGrid(),

            const SizedBox(height: 24),

            // Waktu Shalat Card
            _buildPrayerTimeCard(),

            const SizedBox(height: 24),

            // Stats Cards
            _buildStatsCards(),

            const SizedBox(height: 12),

            Container(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: Icon(FontAwesomeIcons.whatsapp, color: primaryWhite, size: 18),
                label: Text(
                  "MANAGE BUG SENDER",
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 0.5,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFD700),
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(color: const Color(0xFFFFD700).withOpacity(0.5)),
                  ),
                  elevation: 4,
                  shadowColor: const Color(0xFFFFD700).withOpacity(0.5),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ManageSenderPage(
                        sessionKey: sessionKey,
                        username: username,
                        role: role,
                      ),
                    ),
                  );
                },
              ),
            ),

          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────
  //  FEATURE GRID (Admin, Seller, Chat, Al-Quran)
  // ─────────────────────────────────────────────
  Widget _buildFeatureGrid() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section title
        Row(
          children: [
            const Text('⚡ ', style: TextStyle(fontSize: 13)),
            Text(
              'FEATURES',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: accentGrey,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(height: 1, color: primaryBlue.withOpacity(0.3)),
            ),
          ],
        ),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 2.0,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _buildFeatureBtn(
              icon: Icons.computer_rounded,
              iconColor: accentBlue,
              gradientColors: [const Color(0xFF091E42), const Color(0xFF0D2D6B)],
              borderColor: accentBlue.withOpacity(0.5),
              name: 'ADMIN PANEL',
              desc: 'Control center',
              onTap: () {
                Navigator.pushNamed(context, '/admin',
                    arguments: {'sessionKey': sessionKey, 'role': role});
              },
            ),
            _buildFeatureBtn(
              icon: Icons.storefront_rounded,
              iconColor: const Color(0xFF00B4FF),
              gradientColors: [const Color(0xFF081E30), const Color(0xFF0D3555)],
              borderColor: const Color(0xFF00B4FF).withOpacity(0.5),
              name: 'SELLER PAGE',
              desc: 'Marketplace',
              onTap: () {
                Navigator.pushNamed(context, '/seller',
                    arguments: {'keyToken': sessionKey});
              },
            ),
            _buildFeatureBtn(
              icon: Icons.chat_bubble_rounded,
              iconColor: const Color(0xFF7080FF),
              gradientColors: [const Color(0xFF0E1245), const Color(0xFF1A1F6E)],
              borderColor: const Color(0xFF5A64FF).withOpacity(0.5),
              name: 'CHAT GLOBAL',
              desc: 'Live chat',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => GlobalChatPage(
                      username: username,
                      sessionKey: sessionKey,
                      role: role,
                    ),
                  ),
                );
              },
            ),
            _buildFeatureBtn(
              icon: Icons.menu_book_rounded,
              iconColor: const Color(0xFF00C8B4),
              gradientColors: [const Color(0xFF061E28), const Color(0xFF0A3240)],
              borderColor: const Color(0xFF00C8B4).withOpacity(0.5),
              name: 'AL-QURAN',
              desc: 'Read & Listen',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AlQuranPage()),
                );
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildFeatureBtn({
    required IconData icon,
    required Color iconColor,
    required List<Color> gradientColors,
    required Color borderColor,
    required String name,
    required String desc,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradientColors,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: iconColor.withOpacity(0.2),
                border: Border.all(color: iconColor.withOpacity(0.4)),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: primaryWhite,
                      letterSpacing: 0.5,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    desc,
                    style: TextStyle(
                      fontSize: 10,
                      color: accentGrey.withOpacity(0.6),
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: accentGrey.withOpacity(0.4), size: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: [blueGradientStart, blueGradientEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: accentBlue.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.dashboard,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Welcome back",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      "Expolion Dashboard",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _buildQuickStat(
                icon: Icons.people,
                label: "Online Users",
                value: "$onlineUsers",
              ),
              const SizedBox(width: 16),
              _buildQuickStat(
                icon: Icons.link,
                label: "Connections",
                value: "$activeConnections",
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStat({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white70, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    value,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Latest News",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.9),
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              final item = newsList[index];
              return Container(
                margin: const EdgeInsets.only(right: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: cardDark,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (item['image'] != null && item['image'].toString().isNotEmpty)
                        NewsMedia(url: item['image']),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.black.withOpacity(0.7),
                              Colors.transparent,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16,
                        left: 16,
                        right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] ?? 'No Title',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item['desc'] ?? '',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.7),
                                fontSize: 14,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildPrayerTimeCard() {
    final waktuZona = _waktuUtc.add(Duration(hours: _zonaAktif.utcOffset));
    final jamStr =
        '${waktuZona.hour.toString().padLeft(2, '0')}:${waktuZona.minute.toString().padLeft(2, '0')}:${waktuZona.second.toString().padLeft(2, '0')}';
    final menitNow = waktuZona.hour * 60 + waktuZona.minute;

    _WaktuShalat? shalatNext;
    for (final s in _daftarShalatDashboard) {
      final menitShalat = s.jamZona(_zonaAktif) * 60 + s.menitWIB;
      if (menitShalat > menitNow) { shalatNext = s; break; }
    }
    shalatNext ??= _daftarShalatDashboard.first;

    int menitShalatNext = shalatNext.jamZona(_zonaAktif) * 60 + shalatNext.menitWIB;
    if (menitShalatNext <= menitNow) menitShalatNext += 24 * 60;
    final selisih = menitShalatNext - menitNow;
    final sisaStr = '${selisih ~/ 60}j ${selisih % 60}m lagi';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Waktu Shalat',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 10),
        Container(
          decoration: BoxDecoration(
            color: cardDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: accentBlue.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              // ── Jam + Zona Selector ──────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          jamStr,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 2,
                          ),
                        ),
                        Text(
                          _zonaAktif.keterangan,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    // Zona selector pills
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.07),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.all(3),
                      child: Row(
                        children: _ZonaWaktu.values.map((zona) {
                          final aktif = zona == _zonaAktif;
                          return GestureDetector(
                            onTap: () => setState(() => _zonaAktif = zona),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: aktif ? accentBlue : Colors.transparent,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                zona.label,
                                style: TextStyle(
                                  color: aktif ? Colors.white : Colors.white54,
                                  fontSize: 12,
                                  fontWeight: aktif ? FontWeight.bold : FontWeight.normal,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
              // ── Next Prayer Banner ────────────────────────────
              Container(
                margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: accentBlue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: accentBlue.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Text(shalatNext.ikon, style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Shalat Berikutnya: ${shalatNext.nama}',
                          style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11),
                        ),
                        Text(
                          '${shalatNext.formatWaktu(_zonaAktif)} · $sisaStr',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Divider(color: Colors.white12, height: 1),
              // ── Daftar Shalat ─────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                child: Column(
                  children: _daftarShalatDashboard.map((shalat) {
                    final isNext = shalat == shalatNext;
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 3),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: isNext
                            ? accentBlue.withOpacity(0.12)
                            : Colors.white.withOpacity(0.03),
                        borderRadius: BorderRadius.circular(8),
                        border: isNext
                            ? Border.all(color: accentBlue.withOpacity(0.4))
                            : null,
                      ),
                      child: Row(
                        children: [
                          Text(shalat.ikon, style: const TextStyle(fontSize: 16)),
                          const SizedBox(width: 10),
                          Text(
                            shalat.nama,
                            style: TextStyle(
                              color: isNext ? Colors.white : Colors.white70,
                              fontSize: 14,
                              fontWeight: isNext ? FontWeight.w600 : FontWeight.normal,
                            ),
                          ),
                          const Spacer(),
                          if (isNext)
                            Container(
                              margin: const EdgeInsets.only(right: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: accentBlue,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                'NEXT',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          Text(
                            shalat.formatWaktu(_zonaAktif),
                            style: TextStyle(
                              color: isNext ? Colors.white : Colors.white60,
                              fontSize: 14,
                              fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                              fontFamily: 'Rajdhani',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatsCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Account Statistics",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                icon: Icons.person,
                title: "Username",
                value: username,
                color: accentBlue,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                icon: Icons.verified_user,
                title: "Role",
                value: role.toUpperCase(),
                color: _getRoleColor(role),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _buildStatCard(
          icon: Icons.calendar_today,
          title: "Account Expires",
          value: expiredDate,
          color: Colors.orange,
          fullWidth: true,
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    bool fullWidth = false,
  }) {
    return Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAccountInfo() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Quick Actions",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.5,
            children: [
              if (role == "reseller" || role == "owner")
                _buildActionCard(
                  icon: Icons.store,
                  label: "Seller Page",
                  onTap: () => _onDrawerItemSelected(5),
                ),
              if (role == "owner")
                _buildActionCard(
                  icon: Icons.admin_panel_settings,
                  label: "Admin Panel",
                  onTap: () => _onDrawerItemSelected(6),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardDarker,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accentBlue.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: accentBlue, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner":
        return Colors.red;
      case "vip":
        return accentBlue;
      case "reseller":
        return Colors.green;
      case "premium":
        return Colors.orange;
      default:
        return lightBlue;
    }
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: cardDarker,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // Drawer Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [blueGradientStart, blueGradientEnd],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Expolion",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                _buildDrawerInfo("User:", username),
                _buildDrawerInfo("Role:", role),
                _buildDrawerInfo("Expired:", expiredDate),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (role == "reseller" || role == "owner")
            _buildDrawerItem(
              icon: Icons.store,
              label: "Seller Page",
              onTap: () {
                Navigator.pop(context);
                _onDrawerItemSelected(5);
              },
            ),
          if (role == "owner")
            _buildDrawerItem(
              icon: Icons.admin_panel_settings,
              label: "Admin Page",
              onTap: () {
                Navigator.pop(context);
                _onDrawerItemSelected(6);
              },
            ),
          const Divider(color: Colors.white24),
          _buildDrawerItem(
            icon: Icons.logout,
            label: "Logout",
            onTap: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: accentBlue),
      title: Text(
        label,
        style: const TextStyle(color: Colors.white),
      ),
      onTap: onTap,
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardDarker,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: accentBlue,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "Account Information",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            _infoCard(FontAwesomeIcons.user, "Username", username),
            _infoCard(FontAwesomeIcons.calendar, "Expired", expiredDate),
            _infoCard(FontAwesomeIcons.shieldAlt, "Role", role),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.lock_reset, color: Colors.white),
                    label: const Text("Change Password"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentBlue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.logout, color: Colors.white),
                    label: const Text("Logout"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                            (route) => false,
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentBlue.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: accentBlue.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: accentBlue),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentPage() {
    // Tab 0 (Home) always rebuilt dynamically so prayer clock ticks properly
    if (_selectedTabIndex == 0) {
      return _buildNewsPage();
    }
    return _selectedPage;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: const Text(
          "Expolion",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryDark,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          // 🎵 Tombol Mute/Unmute Musik
          IconButton(
            tooltip: _isMuted ? 'Unmute Musik' : 'Mute Musik',
            icon: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: Icon(
                _isMuted
                    ? Icons.music_off_rounded
                    : _isMusicPlaying
                        ? Icons.music_note_rounded
                        : Icons.music_note_outlined,
                key: ValueKey(_isMuted ? 'off' : _isMusicPlaying ? 'on' : 'pause'),
                color: _isMuted
                    ? Colors.grey
                    : _isMusicPlaying
                        ? const Color(0xFFFFD700)
                        : Colors.white54,
              ),
            ),
            onPressed: _toggleMute,
          ),
          // ▶️ Tombol Play/Pause Musik
          IconButton(
            tooltip: _isMusicPlaying ? 'Pause Musik' : 'Play Musik',
            icon: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: Icon(
                _isMusicPlaying
                    ? Icons.pause_circle_outline_rounded
                    : Icons.play_circle_outline_rounded,
                key: ValueKey(_isMusicPlaying),
                color: Colors.white,
              ),
            ),
            onPressed: _togglePlayPause,
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.account_circle, color: Colors.white),
            onPressed: _showAccountMenu,
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: FadeTransition(opacity: _animation, child: _buildCurrentPage()),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: cardDarker,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentBlue,
          unselectedItemColor: Colors.white54,
          currentIndex: _selectedTabIndex < 0 ? 0 : _selectedTabIndex,
          onTap: _onTabTapped,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.message_outlined),
              activeIcon: Icon(Icons.message),
              label: "WhatsApp",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.build_outlined),
              activeIcon: Icon(Icons.build),
              label: "Tools",
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _prayerTimer.cancel();
    _controller.dispose();
    _fadeController.dispose();
    _audioPlayer?.dispose(); // 🎵 dispose music player (nullable safe)
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFFFFD700),
          ),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade800,
          child: const Icon(Icons.error, color: Color(0xFFFFD700)),
        ),
      );
    }
  }
}